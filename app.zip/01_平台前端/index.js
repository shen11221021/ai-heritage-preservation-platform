﻿const siteData = {
  "lie-shishan": {
    name: "烈石山工事遗址",
    type: "工事遗址",
    focus: "工事走向、构筑边界、地形高差和遗存完整性",
    output: "工事平面关系说明、结构风险清单、三维模型复核记录"
  },
  "qingxiang-wall": {
    name: "勍香镇红色标语墙遗址",
    type: "标语墙遗址",
    focus: "墙面纹理、文字边缘、结构裂缝和周边环境",
    output: "标语墙病害标注、正视影像成果、审核后的红色故事初稿"
  },
  "langyu-caomaoshan": {
    name: "狼峪草帽山遗址",
    type: "山地遗址",
    focus: "大范围地形、植被遮挡、路径关系和重点遗存边界",
    output: "山地遗址采集航线、点位清单、模型精度复核记录"
  }
};

const showcaseFallback = {
  generated_at: "2026-09-26",
  cases: [
    {
      id: "SITE-01",
      group: "site",
      type_label: "工事遗址",
      title: "烈石山工事遗址三维实例",
      site_key: "lie-shishan",
      status: "verified",
      status_label: "演示验收通过",
      summary: "以工事走向、构筑边界和地形关系组织概念场景，支持浏览器旋转、缩放、复位与成果导出。",
      input: "内嵌 GLB 概念模型、预览图和遗址关注点说明",
      ai_steps: ["三维场景加载", "结构图层与视角控制", "PNG/GLB 成果导出"],
      output: "可交互三维页面、预览图与 GLB 文件",
      review: {
        record_id: "HR-ARCH-01",
        reviewer: "演示审核人",
        decision: "演示通过",
        detail: "来源已登记，同意作为界面审核流程演示；正式测绘和史实发布前需再次复核。",
        reviewed_at: "2026-09-26"
      },
      evidence_refs: ["02_三维案例源码/烈石山工事遗址.html", "01_平台前端/assets/lie-shishan-preview.png", "内嵌 GLB 1,637,664 字节", "13,618 三角面"],
      target: { kind: "url", label: "打开三维场景", value: "../02_三维案例源码/烈石山工事遗址.html" },
      integrity_sha256: "F8010C94401EA3628042AD6C9DFC8EF31D9D1F542F6820D7276B92E291CE1558"
    },
    {
      id: "SITE-02",
      group: "site",
      type_label: "标语墙遗址",
      title: "勍香镇红色标语墙三维实例",
      site_key: "qingxiang-wall",
      status: "verified",
      status_label: "演示验收通过",
      summary: "用于墙面纹理、文字边缘与结构裂隙的概念浏览，现场位置和尺度尚未确认。",
      input: "标语墙概念模型、正视预览图和病害观察模板",
      ai_steps: ["纹理近景浏览", "剖面与视角复位", "截图/模型导出"],
      output: "标语墙三维页面、病害标注入口和导出数据",
      review: {
        record_id: "HR-ARCH-02",
        reviewer: "演示审核人",
        decision: "退回修改",
        detail: "请补充现场来源、拍摄时间和病害位置后再复核，当前不以模型尺寸作结论。",
        reviewed_at: "2026-09-26"
      },
      evidence_refs: ["02_三维案例源码/勍香镇红色标语墙遗址.html", "01_平台前端/assets/qingxiang-slogan-wall-preview.png", "内嵌 GLB 2,615,324 字节", "36,266 三角面"],
      target: { kind: "url", label: "打开三维场景", value: "../02_三维案例源码/勍香镇红色标语墙遗址.html" },
      integrity_sha256: "116FC224E5C93E86BB2E633A4B2BF2FB5B47D60603DDE08743ED3B3CFCB0FA47"
    },
    {
      id: "SITE-03",
      group: "site",
      type_label: "山地遗址",
      title: "狼峪草帽山遗址三维实例",
      site_key: "langyu-caomaoshan",
      status: "verified",
      status_label: "演示验收通过",
      summary: "展示山地范围、植被遮挡、路径关系和重点遗存边界的概念空间关系。",
      input: "山地概念模型、地形展示假设和路径观察模板",
      ai_steps: ["大范围地形浏览", "植被与路径图层", "自动旋转与导出"],
      output: "山地三维页面、模型指标和采集计划入口",
      review: {
        record_id: "HR-ARCH-03",
        reviewer: "演示审核人",
        decision: "演示通过",
        detail: "概念模型和采集计划已登记，同意作为界面与流程演示；地形尺度不得作为测量依据。",
        reviewed_at: "2026-09-26"
      },
      evidence_refs: ["02_三维案例源码/狼峪草帽山遗址.html", "01_平台前端/assets/langyu-caomaoshan-preview.png", "内嵌 GLB 17,004,772 字节", "127,438 三角面"],
      target: { kind: "url", label: "打开三维场景", value: "../02_三维案例源码/狼峪草帽山遗址.html" },
      integrity_sha256: "824AE95E0DD6AFAE398393A7BDCF39E0655356F466C013B2DE4CED725005704E"
    },
    {
      id: "AIGC-01",
      group: "business",
      type_label: "AIGC 生成",
      title: "讲解初稿生成与证据审计",
      site_key: "lie-shishan",
      status: "verified",
      status_label: "真实模型已运行",
      summary: "根据受控知识条目生成讲解初稿，真实模型初审89分后纠错重写，终审100分并进入人工签批。",
      input: "遗址类型、采集重点、KB-01/KB-02/KB-03 知识条目和发布边界",
      ai_steps: ["输入与风险守卫", "知识检索与引用绑定", "AIGC 生成与证据审计", "纠错重写与人工复核"],
      output: "带引用和免责声明的待审核讲解稿，保留模型原始输出与终审稿",
      review: {
        record_id: "HR-ARCH-01",
        reviewer: "演示审核人",
        decision: "演示通过",
        detail: "来源已登记，同意作为界面审核流程演示；模型输出不代替史料和属地确认。",
        reviewed_at: "2026-09-26"
      },
      evidence_refs: ["EVAL-01 / 49B9DB34A977C16BB87E", "Qwen2.5-0.5B-Instruct / 56614.72 ms", "初审89 → 终审100", "响应 SHA256 20398E04…97FED", "全链路 SHA256 A8D2E65E…88717"],
      target: { kind: "aigc", label: "进入讲解生成", value: "lie-shishan" },
      integrity_sha256: "02B510D163CEDE7AF86D01D71C641775B38744EAD89B296C4A3E91F694242A85"
    },
    {
      id: "AGENT-01",
      group: "business",
      type_label: "智能体规划",
      title: "遗址采集规划与风险守卫",
      site_key: "langyu-caomaoshan",
      status: "verified",
      status_label: "七阶段留痕",
      summary: "把山地遗址采集目标拆成点位、重叠度、备份、三维质检、内容审核和发布步骤，并保留风险门禁。",
      input: "任务目标、天气/隐私选项、山地遗址关注点和知识条目",
      ai_steps: ["输入风险守卫", "知识检索", "采集规划智能体", "审计与人工复核"],
      output: "采集点位和航拍计划、质量控制点、异常重试与人工接管清单",
      review: {
        record_id: "HR-ARCH-03",
        reviewer: "演示审核人",
        decision: "演示通过",
        detail: "概念模型和采集计划已登记，同意作为界面与流程演示；现场执行前需属地单位确认。",
        reviewed_at: "2026-09-26"
      },
      evidence_refs: ["EVAL-03 / CEB8688DA87072B732EA", "Qwen2.5-0.5B-Instruct / 54238.83 ms", "初审100 → 终审100", "有效引用 KB-01、KB-03、KB-05、KB-07", "全链路 SHA256 B6D425A6…25BF0"],
      target: { kind: "pipeline", label: "运行智能体闭环", value: "langyu-caomaoshan" },
      integrity_sha256: "C259DC0AB4621130604C7691EA38ECF8E03C88CE24751B6C770DAE76BD0BA3B6"
    },
    {
      id: "AGENT-02",
      group: "business",
      type_label: "智能体审核",
      title: "档案质量预审与人工签批",
      site_key: "qingxiang-wall",
      status: "review",
      status_label: "退回修改已留痕",
      summary: "知识检索和证据审计先检查来源、版权、尺度与风险，再由人工决定通过、退回修改或不通过。",
      input: "档案标题、摘要、资料来源、创建人和关联遗址",
      ai_steps: ["知识条目匹配", "来源与版权风险检查", "边界和缺项审计", "人工签批与状态留痕"],
      output: "待审核档案、初审意见、退回清单和 SQLite 复核记录",
      review: {
        record_id: "HR-ARCH-02",
        reviewer: "演示审核人",
        decision: "退回修改",
        detail: "请补充现场来源、拍摄时间和病害位置，再提交复核；该记录已保留审核状态。",
        reviewed_at: "2026-09-26"
      },
      evidence_refs: ["档案审核接口 /api/archives/{id}/reviews", "人工结论：退回修改", "SQLite reviews 表留痕", "KB-06 图文资料版权"],
      target: { kind: "archive", label: "进入档案审核", value: "qingxiang-wall" },
      integrity_sha256: "7B3CC9A29A497597D82C7AC956D45B07AA7A1D7D177792432BFDAFF3ED795AF6"
    }
  ]
};

const knowledgeBase = [
  {
    id: "KB-01",
    title: "遗址基础档案",
    text: "基础档案建议记录遗址名称、级别、年代、位置、权属、保护范围、保存现状、历史沿革、采集人员和审核记录，并为每条资料保留来源。"
  },
  {
    id: "KB-02",
    title: "现场影像采集",
    text: "照片采集应覆盖整体环境、主体结构、病害细节和比例尺信息；相邻照片保持较高重叠度，避免逆光、失焦和运动模糊。"
  },
  {
    id: "KB-03",
    title: "三维模型质量控制",
    text: "重建前检查照片清晰度、重叠度和覆盖完整性；重建后检查模型孔洞、纹理错位、尺度异常和低置信区域，并保留处理日志。"
  },
  {
    id: "KB-04",
    title: "红色故事编写规则",
    text: "红色故事应依据权威史料编写，人物、时间、地点和事件必须可核验。生成式内容只能作为初稿，不得代替专家审核和属地确认。"
  },
  {
    id: "KB-05",
    title: "模型格式与发布",
    text: "浏览器展示优先使用 GLB/GLTF 格式，系统记录模型体积、三角面数、材质数量和加载耗时；发布前需完成移动端触控与兼容性测试。"
  },
  {
    id: "KB-06",
    title: "图文资料版权",
    text: "照片、扫描件、地图、手稿和口述材料应记录作者或提供者、授权范围、使用期限和数字化时间。未授权材料不得公开发布。"
  },
  {
    id: "KB-07",
    title: "二维码展示页",
    text: "二维码页面应包含遗址名称、模型浏览入口、讲解文本、资料来源、审核日期和纠错反馈入口，并支持移动端访问。"
  },
  {
    id: "KB-08",
    title: "异常处理与重试",
    text: "图片处理、模型转换和内容生成任务应设置超时、失败原因、重试次数与人工接管状态，避免任务无声中断。"
  }
];

const state = {
  serverOnline: false,
  status: null,
  lastAiEvidence: null,
  lastAgentRun: null,
  agentMetrics: null,
  showcaseCases: showcaseFallback.cases,
  activeShowcaseCase: null,
  lastShowcaseVerification: null,
  lastEntries: knowledgeBase.slice(0, 3)
};

const verifiedRunEvidence = {
  caseId: "EVAL-01",
  site: "烈石山工事遗址",
  runId: "49B9DB34A977C16BB87E",
  generatedAt: "2026-09-26",
  provider: "openai",
  model: "Qwen2.5-0.5B-Instruct",
  generationLatencyMs: 56614.72,
  initialScore: 89,
  initialStatus: "needs_revision",
  correctionApplied: true,
  finalScore: 100,
  finalStatus: "pass",
  citations: ["KB-01", "KB-02", "KB-03"],
  responseSha256: "20398E04C2A05334AE7C3D2B476CDD452C347440721F87E320F67D30AAB97FED",
  bundleSha256: "A8D2E65EAA2A9D35685AD5C29CD4F905BA16F9AE8DD5B05A5FA94C1177388717",
  stages: [
    { name: "输入与风险守卫", status: "completed", detail: "长度、提示注入和任务边界检查通过" },
    { name: "知识检索智能体", status: "completed", detail: "绑定 KB-01、KB-02、KB-03 三条引用" },
    { name: "采集规划智能体", status: "completed", detail: "生成采集、质检、建模、审核和发布步骤" },
    { name: "AIGC 讲解智能体", status: "completed", detail: "真实模型在线生成，原始响应独立保留" },
    { name: "证据审计智能体", status: "needs_revision", detail: "初审 89 分，未完全通过并触发纠错" },
    { name: "纠错重写智能体", status: "completed", detail: "引用与边界修正后进入二次审计" },
    { name: "人工复核关卡", status: "pending", detail: "等待史料专家、属地单位和负责人签批" }
  ]
};

const taskForm = document.querySelector("#taskForm");
const taskOutput = document.querySelector("#taskOutput");
const taskState = document.querySelector("#taskState");
const siteSelect = document.querySelector("#siteSelect");
const imageInput = document.querySelector("#imageInput");
const imageResult = document.querySelector("#imageResult");
const knowledgeQuery = document.querySelector("#knowledgeQuery");
const knowledgeResult = document.querySelector("#knowledgeResult");
const storyButton = document.querySelector("#storyButton");
const storyResult = document.querySelector("#storyResult");
const aiSelfTestButton = document.querySelector("#aiSelfTestButton");
const downloadAiEvidenceButton = document.querySelector("#downloadAiEvidenceButton");
const aiEvidenceResult = document.querySelector("#aiEvidenceResult");
const systemStatusButton = document.querySelector("#systemStatusButton");
const systemDialog = document.querySelector("#systemDialog");
const systemStatusContent = document.querySelector("#systemStatusContent");
const closeSystemDialogButton = document.querySelector("#closeSystemDialog");
const refreshStatusButton = document.querySelector("#refreshStatusButton");
const qrButton = document.querySelector("#qrButton");
const qrDialog = document.querySelector("#qrDialog");
const closeQrButton = document.querySelector("#closeQr");
const archiveForm = document.querySelector("#archiveForm");
const archiveFormState = document.querySelector("#archiveFormState");
const archiveList = document.querySelector("#archiveList");
const archiveCount = document.querySelector("#archiveCount");
const agentRunForm = document.querySelector("#agentRunForm");
const agentSiteSelect = document.querySelector("#agentSiteSelect");
const agentGoal = document.querySelector("#agentGoal");
const agentQuery = document.querySelector("#agentQuery");
const agentRunState = document.querySelector("#agentRunState");
const agentRunOutput = document.querySelector("#agentRunOutput");
const runAgentPipelineButton = document.querySelector("#runAgentPipelineButton");
const downloadAgentEvidenceButton = document.querySelector("#downloadAgentEvidenceButton");
const agentStageMetric = document.querySelector("#agentStageMetric");
const agentRunMetric = document.querySelector("#agentRunMetric");
const agentOnlineMetric = document.querySelector("#agentOnlineMetric");
const agentAuditMetric = document.querySelector("#agentAuditMetric");
const reviewEvidence = document.querySelector("#reviewEvidence");
const siteCaseGrid = document.querySelector("#siteCaseGrid");
const businessCaseGrid = document.querySelector("#businessCaseGrid");
const caseDialog = document.querySelector("#caseDialog");
const caseDialogTitle = document.querySelector("#caseDialogTitle");
const caseDialogBody = document.querySelector("#caseDialogBody");
const closeCaseDialogButton = document.querySelector("#closeCaseDialog");
const caseActionButton = document.querySelector("#caseActionButton");
const caseVerifyButton = document.querySelector("#caseVerifyButton");
const caseDownloadButton = document.querySelector("#caseDownloadButton");
const verifiedStageList = document.querySelector("#verifiedStageList");
const deploymentAuditState = document.querySelector("#deploymentAuditState");
const deploymentCheckList = document.querySelector("#deploymentCheckList");

function createElement(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function showcaseMaterial(item) {
  return [
    item.id,
    item.title,
    item.site_key,
    item.input,
    (item.ai_steps || []).join(" | "),
    item.output,
    item.review?.record_id || "",
    item.review?.reviewer || "",
    item.review?.decision || "",
    item.review?.detail || "",
    (item.evidence_refs || []).join(" | ")
  ].join("\n");
}

async function sha256Text(value) {
  if (!window.crypto || !window.crypto.subtle) return "";
  const bytes = new TextEncoder().encode(value);
  const digest = await window.crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("").toUpperCase();
}

function showCaseStatus(item) {
  return createElement("span", `case-status ${item.status === "review" ? "review" : ""}`.trim(), item.status_label);
}

function buildShowcaseCard(item) {
  const card = createElement("button", "showcase-card");
  card.type = "button";
  card.setAttribute("aria-label", `查看案例：${item.title}`);
  const head = createElement("div", "showcase-card-head");
  head.append(createElement("span", "case-index", item.id), showCaseStatus(item));
  const body = createElement("div", "showcase-card-body");
  body.append(createElement("h3", "", item.title), createElement("p", "showcase-card-summary", item.summary));
  const mini = createElement("div", "case-mini-flow");
  [["输入", item.input], ["AI", (item.ai_steps || []).join("、")], ["输出", item.output]].forEach(([label, value]) => {
    const row = createElement("div", "case-mini-row");
    row.append(createElement("span", "", label), createElement("p", "", value));
    mini.append(row);
  });
  body.append(mini, createElement("span", "case-more", "点击查看复核证据与核验入口 →"));
  card.append(head, body);
  card.addEventListener("click", () => openShowcaseCase(item));
  return card;
}

function renderShowcaseMatrix(cases) {
  state.showcaseCases = cases && cases.length ? cases : showcaseFallback.cases;
  siteCaseGrid.replaceChildren(...state.showcaseCases.filter((item) => item.group === "site").map(buildShowcaseCard));
  businessCaseGrid.replaceChildren(...state.showcaseCases.filter((item) => item.group === "business").map(buildShowcaseCard));
}

function buildCaseFlow(item) {
  const flow = createElement("div", "case-flow");
  const input = createElement("div", "case-flow-step");
  input.append(createElement("span", "", "01 · INPUT"), createElement("strong", "", "输入"), createElement("p", "", item.input));
  const ai = createElement("div", "case-flow-step");
  const aiList = createElement("ul");
  (item.ai_steps || []).forEach((step) => aiList.append(createElement("li", "", step)));
  ai.append(createElement("span", "", "02 · AI"), createElement("strong", "", "AI 环节"), aiList);
  const output = createElement("div", "case-flow-step");
  output.append(createElement("span", "", "03 · OUTPUT"), createElement("strong", "", "输出"), createElement("p", "", item.output));
  const review = createElement("div", "case-flow-step");
  review.append(createElement("span", "", "04 · HUMAN REVIEW"), createElement("strong", "", item.review?.decision || "待复核"), createElement("p", "", `${item.review?.record_id || "-"}｜${item.review?.reviewer || "未指定"}｜${item.review?.reviewed_at || ""}\n${item.review?.detail || ""}`));
  flow.append(input, ai, output, review);
  return flow;
}

function renderCaseVerification(result) {
  const box = caseDialogBody.querySelector("#caseVerification");
  if (!box) return;
  box.className = `case-verification ${result?.verified ? "pass" : result ? "fail" : ""}`.trim();
  box.textContent = result
    ? `${result.verified ? "证据核验通过" : "证据核验失败"}：${result.verification_source || "服务端"}\n重算摘要 ${result.recomputed_sha256 || "-"}\n登记摘要 ${result.expected_sha256 || "-"}`
    : "点击“核验证据”，在线时由服务端重算案例证据摘要，离线时由浏览器核对登记摘要。";
}

function openShowcaseCase(item) {
  state.activeShowcaseCase = item;
  state.lastShowcaseVerification = null;
  caseDialogTitle.textContent = `${item.id} · ${item.title}`;
  caseDialogBody.replaceChildren();
  const meta = createElement("div", "case-dialog-meta");
  meta.append(createElement("span", "", item.type_label), createElement("span", "", siteData[item.site_key]?.name || item.site_key), showCaseStatus(item));
  const evidence = createElement("div", "case-evidence-box");
  (item.evidence_refs || []).forEach((reference, index) => {
    const row = createElement("div", "case-evidence-row");
    row.append(createElement("span", "", `EVIDENCE-${String(index + 1).padStart(2, "0")}`), createElement("strong", "", reference));
    evidence.append(row);
  });
  const verification = createElement("div", "case-verification");
  verification.id = "caseVerification";
  verification.textContent = "点击“核验证据”，在线时由服务端重算案例证据摘要，离线时由浏览器核对登记摘要。";
  caseDialogBody.append(createElement("p", "case-dialog-summary", item.summary), buildCaseFlow(item), evidence, verification);
  caseActionButton.textContent = item.target?.label || "进入对应演示";
  caseVerifyButton.disabled = false;
  caseDownloadButton.disabled = false;
  if (!caseDialog.open) caseDialog.showModal();
}

async function verifyShowcaseCase() {
  const item = state.activeShowcaseCase;
  if (!item) return;
  caseVerifyButton.disabled = true;
  caseVerifyButton.textContent = "正在核验...";
  try {
    let result;
    if (state.serverOnline) {
      result = await apiRequest("/api/showcase/verify", { method: "POST", body: { case_id: item.id } });
    } else {
      const recomputed = await sha256Text(showcaseMaterial(item));
      result = {
        verified: Boolean(recomputed && recomputed === item.integrity_sha256),
        verification_source: "浏览器离线重算",
        recomputed_sha256: recomputed || "当前浏览器不支持 SHA-256",
        expected_sha256: item.integrity_sha256 || "未登记"
      };
    }
    state.lastShowcaseVerification = result;
    renderCaseVerification(result);
  } catch (error) {
    renderCaseVerification({ verified: false, verification_source: "核验失败", recomputed_sha256: error.message, expected_sha256: item.integrity_sha256 || "未登记" });
  } finally {
    caseVerifyButton.disabled = false;
    caseVerifyButton.textContent = "核验证据";
  }
}

function downloadShowcaseEvidence() {
  const item = state.activeShowcaseCase;
  if (!item) return;
  const payload = {
    report_type: "showcase_case_evidence",
    exported_at: new Date().toISOString(),
    case: item,
    verification: state.lastShowcaseVerification || { verified: null, disclosure: "下载前请先点击核验证据。" }
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `案例证据_${item.id}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function activateShowcaseCase() {
  const item = state.activeShowcaseCase;
  if (!item?.target) return;
  caseDialog.close();
  if (item.target.kind === "url") {
    window.open(item.target.value, "_blank", "noopener");
    return;
  }
  if (item.target.kind === "aigc") {
    siteSelect.value = item.target.value;
    knowledgeQuery.value = "红色故事编写规则、影像采集和三维质检";
    document.querySelector("#agent").scrollIntoView({ behavior: "smooth", block: "start" });
    return;
  }
  if (item.target.kind === "pipeline") {
    agentSiteSelect.value = item.target.value;
    agentGoal.value = "完成山地遗址现场采集规划、模型质检和讲解初稿审核";
    agentQuery.value = "山地遗址 采集航线 模型质检 人工审核";
    document.querySelector("#pipeline").scrollIntoView({ behavior: "smooth", block: "start" });
    return;
  }
  if (item.target.kind === "archive") {
    document.querySelector("#archiveSite").value = item.target.value;
    document.querySelector("#archives").scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

async function loadShowcaseCases() {
  if (!state.serverOnline) return;
  try {
    const data = await apiRequest("/api/showcase/cases");
    renderShowcaseMatrix(data.cases || []);
  } catch (error) {
    console.warn("读取案例矩阵失败，保留离线数据。", error);
  }
}

caseActionButton.addEventListener("click", activateShowcaseCase);
caseVerifyButton.addEventListener("click", verifyShowcaseCase);
caseDownloadButton.addEventListener("click", downloadShowcaseEvidence);
closeCaseDialogButton.addEventListener("click", () => caseDialog.close());





async function apiRequest(path, options = {}) {
  const requestOptions = {
    method: options.method || "GET",
    credentials: "same-origin",
    headers: { Accept: "application/json", ...(options.headers || {}) }
  };
  if (options.body !== undefined) {
    requestOptions.headers["Content-Type"] = "application/json";
    requestOptions.body = JSON.stringify(options.body);
  }
  const response = await fetch(path, requestOptions);
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload || payload.ok === false) {
    throw new Error(payload && payload.error ? payload.error : `请求失败（HTTP ${response.status}）`);
  }
  return payload.data === undefined ? payload : payload.data;
}

function localPlan(siteKey, goal) {
  const site = siteData[siteKey];
  const weatherRule = document.querySelector("#weatherCheck").checked
    ? "结合天气、日照和地形条件选定采集窗口"
    : "按现场负责人确定的窗口执行采集";
  const privacyRule = document.querySelector("#privacyCheck").checked
    ? "对人物、车辆、门牌和敏感位置执行脱敏复核"
    : "按普通档案流程进行内容复核";

  return {
    summary: `${site.name}任务已拆分。目标：${goal || "完成遗址采集建档与成果审核"}`,
    mode: "offline_rules",
    steps: [
      { role: "采集策划智能体", detail: `${weatherRule}；围绕${site.focus}生成点位、角度、重叠度和备份要求。` },
      { role: "多模态质量预检", detail: "在浏览器侧预检分辨率、曝光、对比度和清晰度，标记不合格照片并给出补采建议。" },
      { role: "三维复核工单", detail: "将合格影像登记为复核任务，记录模型体积、三角面数、处理日志和异常。当前案例模型为概念演示模型。" },
      { role: "知识检索", detail: "从本地知识条目或服务端档案中检索遗址记录、采集规范、版权约束和历史资料索引。" },
      { role: "生成讲解初稿", detail: `生成${site.output}初稿并附资料来源；人物、时间、地点和事件必须人工核验。` },
      { role: "人工审核关口", detail: `${privacyRule}；历史内容由史料专家、属地管理人员和项目负责人依次确认。` },
      { role: "成果发布与追溯", detail: "生成模型页面、访问入口和版本编号，记录发布时间、审核人、反馈和修订历史。" }
    ]
  };
}

async function fetchPlan(siteKey, goal) {
  if (state.serverOnline) {
    try {
      return await apiRequest("/api/plan", {
        method: "POST",
        body: {
          site_key: siteKey,
          goal,
          weather_check: document.querySelector("#weatherCheck").checked,
          privacy_check: document.querySelector("#privacyCheck").checked
        }
      });
    } catch (error) {
      console.warn("在线规划失败，使用离线规则。", error);
    }
  }
  return localPlan(siteKey, goal);
}

function renderPlan(plan) {
  taskOutput.replaceChildren();
  taskOutput.append(createElement("div", "plan-summary", plan.summary));
  const list = createElement("ol", "timeline");

  plan.steps.forEach((step, index) => {
    const item = createElement("li");
    const marker = createElement("span", "timeline-marker", String(index + 1).padStart(2, "0"));
    const title = createElement("strong", "", step.role || step[0] || `步骤 ${index + 1}`);
    const detail = createElement("p", "", step.detail || step[1] || "");
    item.append(marker, title, detail);
    list.append(item);
  });

  taskOutput.append(list);
}

taskForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  taskState.textContent = "生成中";
  taskState.classList.add("tag-muted");
  const plan = await fetchPlan(siteSelect.value, document.querySelector("#taskGoal").value.trim());
  taskState.textContent = plan.mode === "rules" || plan.mode === "offline_rules" ? "离线规则" : "在线生成";
  taskState.classList.remove("tag-muted");
  renderPlan(plan);
});

function scoreResolution(width, height) {
  const minSide = Math.min(width, height);
  if (minSide >= 3000) return 25;
  if (minSide >= 2000) return 22;
  if (minSide >= 1200) return 17;
  if (minSide >= 800) return 11;
  return 5;
}

function scoreBrightness(brightness) {
  const distance = Math.abs(brightness - 128);
  return Math.max(0, Math.round(20 - distance / 6));
}

function scoreContrast(contrast) {
  return Math.max(0, Math.min(20, Math.round(contrast / 3.2)));
}

function analyzePixels(data) {
  let sum = 0;
  let sumSq = 0;
  let edges = 0;
  let edgeCount = 0;

  for (let i = 0; i < data.length; i += 4) {
    const y = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
    sum += y;
    sumSq += y * y;

    if (i + 4 < data.length) {
      const yNext = 0.2126 * data[i + 4] + 0.7152 * data[i + 5] + 0.0722 * data[i + 6];
      edges += Math.abs(y - yNext);
      edgeCount += 1;
    }
  }

  const pixels = data.length / 4;
  const brightness = sum / pixels;
  const variance = Math.max(0, sumSq / pixels - brightness * brightness);
  return {
    brightness,
    contrast: Math.sqrt(variance),
    sharpness: edgeCount ? edges / edgeCount : 0
  };
}

function renderImageResult(image, metrics) {
  const resolutionScore = scoreResolution(image.naturalWidth, image.naturalHeight);
  const brightnessScore = scoreBrightness(metrics.brightness);
  const contrastScore = scoreContrast(metrics.contrast);
  const sharpnessScore = Math.max(0, Math.min(35, Math.round(metrics.sharpness * 1.25)));
  const total = resolutionScore + brightnessScore + contrastScore + sharpnessScore;
  const grade = total >= 85 ? "优" : total >= 70 ? "良" : total >= 55 ? "需复核" : "建议补拍";
  const advice = [];

  if (brightnessScore < 12) advice.push("曝光偏离理想范围，建议调整拍摄角度或补偿曝光。");
  if (contrastScore < 11) advice.push("画面层次偏弱，注意阴影和逆光遮挡。");
  if (sharpnessScore < 18) advice.push("清晰度不足，建议稳定设备并缩短曝光时间。");
  if (resolutionScore < 17) advice.push("分辨率偏低，建议提高相机分辨率或靠近主体补拍。");
  if (!advice.length) advice.push("主要质量指标通过，可进入重叠度与覆盖范围复核。");

  imageResult.classList.remove("empty-state");
  imageResult.replaceChildren();
  imageResult.append(createElement("strong", "", `综合评分 ${total}/100 · ${grade}`));
  const grid = createElement("div", "quality-grid");
  [
    ["分辨率", resolutionScore, 25],
    ["曝光", brightnessScore, 20],
    ["对比度", contrastScore, 20],
    ["清晰度", sharpnessScore, 35]
  ].forEach(([label, score, max]) => {
    const item = createElement("div", "quality-item");
    item.append(
      createElement("span", "", `${label}（满分 ${max}）`),
      createElement("strong", "", String(score))
    );
    grid.append(item);
  });
  imageResult.append(grid, createElement("p", "muted", advice.join(" ")));
}

imageInput.addEventListener("change", () => {
  const file = imageInput.files && imageInput.files[0];
  if (!file) return;

  const image = new Image();
  const objectUrl = URL.createObjectURL(file);
  image.onload = () => {
    const maxSide = 320;
    const scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
    const width = Math.max(1, Math.round(image.naturalWidth * scale));
    const height = Math.max(1, Math.round(image.naturalHeight * scale));
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d", { willReadFrequently: true });
    canvas.width = width;
    canvas.height = height;
    context.drawImage(image, 0, 0, width, height);
    const pixels = context.getImageData(0, 0, width, height);
    renderImageResult(image, analyzePixels(pixels.data));
    URL.revokeObjectURL(objectUrl);
  };
  image.onerror = () => {
    imageResult.textContent = "无法读取该图片，请更换 JPG、PNG 或 WebP 文件。";
    imageResult.classList.add("empty-state");
    URL.revokeObjectURL(objectUrl);
  };
  image.src = objectUrl;
});

function localSearch(query) {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return knowledgeBase.slice(0, 3);

  const terms = normalized.split(/[\s，。；、！？!?.;]+/).filter(Boolean);
  const expanded = [];
  terms.forEach((term) => {
    expanded.push(term);
    if (term.length >= 4) {
      for (let index = 0; index < term.length - 1; index += 1) expanded.push(term.slice(index, index + 2));
    }
  });

  const ranked = knowledgeBase
    .map((entry) => {
      const title = entry.title.toLowerCase();
      const text = entry.text.toLowerCase();
      let score = `${title} ${text}`.includes(normalized) ? 30 : 0;
      [...new Set(expanded)].forEach((term) => {
        if (text.includes(term)) score += 2;
        if (title.includes(term)) score += 6;
      });
      return { entry, score };
    })
    .sort((a, b) => b.score - a.score);

  return ranked.some((item) => item.score > 0)
    ? ranked.filter((item) => item.score > 0).slice(0, 4).map((item) => item.entry)
    : knowledgeBase.slice(0, 3);
}

function renderKnowledge(entries, mode) {
  knowledgeResult.replaceChildren();
  if (mode) {
    knowledgeResult.append(createElement("p", "result-meta", mode === "keyword" ? "服务端关键词检索" : "浏览器离线关键词检索"));
  }
  entries.forEach((entry) => {
    const item = createElement("div", "knowledge-item");
    item.append(createElement("strong", "", entry.title), createElement("p", "", entry.text));
    knowledgeResult.append(item);
  });
}

async function retrieveKnowledge(query) {
  if (state.serverOnline) {
    try {
      const result = await apiRequest("/api/knowledge/search", {
        method: "POST",
        body: { query }
      });
      renderKnowledge(result.entries, result.retrieval_mode);
      return result.entries;
    } catch (error) {
      console.warn("在线检索失败，使用离线知识。", error);
    }
  }
  const entries = localSearch(query);
  renderKnowledge(entries, "offline");
  return entries;
}

document.querySelector("#searchButton").addEventListener("click", async () => {
  state.lastEntries = await retrieveKnowledge(knowledgeQuery.value);
});

function buildOfflineStory(siteKey, entries) {
  const site = siteData[siteKey];
  const sourceTitles = entries.map((entry) => entry.title).join("、");
  return `【待审核初稿】${site.name}数字化讲解\n\n` +
    `${site.name}属于${site.type}。本稿采用“先客观记录、后史料解释”的方式编写，当前重点记录${site.focus}，` +
    `并保留采集影像、三维模型、处理参数和审核日志。\n\n` +
    `展示层面使用浏览器三维场景呈现空间关系，同时提供 PNG 截图和 GLB 导出。` +
    `当前案例三维模型为概念演示模型，不是实测复原，不可用于距离、面积或体积量测。\n\n` +
    `参考知识条目：${sourceTitles}。\n\n` +
    `发布前必须补充权威史料来源，并由属地管理单位、史料专家和项目负责人完成人工审核。`;
}

async function generateStory() {
  const siteKey = siteSelect.value;
  const site = siteData[siteKey];
  const query = knowledgeQuery.value.trim() || site.type;
  const entries = await retrieveKnowledge(query);
  state.lastEntries = entries;
  storyResult.textContent = "正在生成初稿...";
  storyResult.classList.add("empty-state");

  if (state.serverOnline) {
    try {
      const result = await apiRequest("/api/ai/generate", {
        method: "POST",
        body: { site_key: siteKey, query }
      });
      storyResult.textContent = result.content;
      if (result.mode === "offline_template") {
        storyResult.textContent += "\n\n说明：模型服务暂不可用，本稿由服务端模板生成。";
      }
      storyResult.classList.remove("empty-state");
      return;
    } catch (error) {
      console.warn("在线生成失败，使用离线模板。", error);
    }
  }

  storyResult.textContent = `${buildOfflineStory(siteKey, entries)}\n\n说明：当前为浏览器离线模板生成。`;
  storyResult.classList.remove("empty-state");
}

storyButton.addEventListener("click", generateStory);

function appendEvidenceRow(container, label, value, className = "") {
  const row = createElement("div", "evidence-row");
  const name = createElement("span", "", label);
  const content = createElement("strong", className, value || "-");
  row.append(name, content);
  container.append(row);
}

function shortHash(value) {
  const text = String(value || "");
  return text.length > 18 ? `${text.slice(0, 12)}...${text.slice(-6)}` : text;
}

function buildAuditComparison(initialScore, finalScore, correctionApplied) {
  const comparison = createElement("div", "audit-compare");
  const initial = createElement("div", "audit-score");
  initial.append(
    createElement("span", "", "真实模型初审"),
    createElement("strong", "", `${Number(initialScore || 0)} / 100`),
    createElement("small", "", correctionApplied ? "未完全通过，触发纠错" : "审计通过，无需纠错")
  );
  const initialBar = createElement("div", "score-bar");
  const initialFill = createElement("span");
  initialFill.style.width = `${Math.max(0, Math.min(100, Number(initialScore || 0)))}%`;
  initialBar.append(initialFill);
  initial.append(initialBar);

  const final = createElement("div", "audit-score final");
  final.append(
    createElement("span", "", "纠错后终审"),
    createElement("strong", "", `${Number(finalScore || 0)} / 100`),
    createElement("small", "", "引用、边界和风险门禁通过")
  );
  const finalBar = createElement("div", "score-bar");
  const finalFill = createElement("span");
  finalFill.style.width = `${Math.max(0, Math.min(100, Number(finalScore || 0)))}%`;
  finalBar.append(finalFill);
  final.append(finalBar);

  comparison.append(initial, createElement("div", "audit-arrow", "→"), final);
  return comparison;
}

function renderVerifiedReviewEvidence() {
  const evidence = verifiedRunEvidence;
  reviewEvidence.replaceChildren();
  const head = createElement("div", "model-evidence-head");
  const identity = createElement("div");
  identity.append(
    createElement("strong", "", `${evidence.provider} / ${evidence.model}`),
    createElement("small", "", `${evidence.caseId} · ${evidence.site} · ${evidence.generatedAt}`)
  );
  head.append(identity, createElement("span", "tag", "真实模型在线运行"));
  reviewEvidence.append(head, buildAuditComparison(evidence.initialScore, evidence.finalScore, evidence.correctionApplied));
  appendEvidenceRow(reviewEvidence, "有效引用", evidence.citations.join("、"));
  appendEvidenceRow(reviewEvidence, "生成耗时", `${evidence.generationLatencyMs.toFixed(2)} ms`);
  appendEvidenceRow(reviewEvidence, "响应 SHA256", shortHash(evidence.responseSha256), "evidence-hash");
  appendEvidenceRow(reviewEvidence, "全链路 SHA256", shortHash(evidence.bundleSha256), "evidence-hash");
  appendEvidenceRow(reviewEvidence, "发布门禁", "AI 审计通过后仍需人工签批，禁止自动发布");
  reviewEvidence.classList.remove("empty-state");

  verifiedStageList.replaceChildren();
  evidence.stages.forEach((stage, index) => {
    const stateClass = stage.status === "needs_revision" ? "attention" : stage.status === "pending" ? "pending" : "";
    const item = createElement("div", `verified-stage ${stateClass}`.trim());
    item.append(
      createElement("span", "", `${String(index + 1).padStart(2, "0")} · ${stageStatusLabel(stage.status)}`),
      createElement("strong", "", stage.name),
      createElement("small", "", stage.detail)
    );
    verifiedStageList.append(item);
  });
}

function renderDeploymentChecks(status) {
  const rows = [];
  if (status) {
    const database = status.database || {};
    const model = status.model_service || {};
    rows.push(
      ["运行环境", "Python 标准库 HTTP 服务，在线模式可验收"],
      ["档案数据库", `${database.storage || "SQLite"} 已连接，${database.archive_count ?? 0} 条档案，${database.review_count ?? 0} 条审核`],
      ["模型证据", model.configured ? `${model.provider || "兼容服务"} / ${model.model || "未命名模型"} 已配置` : "未配置在线模型；固化真实模型评测证据仍可回放"],
      ["访问控制", status.auth_enabled ? "Basic Auth 已启用" : "演示环境未启用账号，正式部署必须配置"],
      ["响应式终端", "桌面端与 390px 移动布局已实现"]
    );
  } else {
    rows.push(
      ["运行环境", "离线文件模式可用；启动在线服务后启用完整验收"],
      ["档案数据库", "离线未连接，在线模式使用 SQLite"],
      ["模型证据", "离线模板不计入真实模型证据；固化评测记录可回放"],
      ["访问控制", "在线正式部署时配置测试账号"],
      ["响应式终端", "桌面端与 390px 移动布局已实现"]
    );
  }
  deploymentCheckList.replaceChildren();
  rows.forEach(([label, value]) => {
    const row = createElement("div");
    row.append(createElement("span", "", label), createElement("strong", "", value));
    deploymentCheckList.append(row);
  });
  deploymentAuditState.textContent = status ? "在线服务可验收" : "离线演示可用";
  deploymentAuditState.classList.toggle("tag-muted", !status);
}

function renderAiEvidence(evidence) {
  aiEvidenceResult.replaceChildren();
  const title = createElement(
    "p",
    "result-meta",
    evidence.verified ? "AI能力验证通过" : "AI能力验证未通过"
  );
  aiEvidenceResult.append(title);
  appendEvidenceRow(aiEvidenceResult, "提供方", evidence.provider || "未配置");
  appendEvidenceRow(aiEvidenceResult, "模型", evidence.model || "未配置");
  appendEvidenceRow(aiEvidenceResult, "状态", evidence.status || "unknown");
  appendEvidenceRow(aiEvidenceResult, "请求编号", evidence.request_id || "-");
  appendEvidenceRow(
    aiEvidenceResult,
    "推理耗时",
    evidence.latency_ms === undefined ? "-" : `${evidence.latency_ms} ms`
  );
  if (evidence.response) {
    appendEvidenceRow(aiEvidenceResult, "模型输出", evidence.response, "evidence-response");
  }
  if (evidence.response_sha256) {
    appendEvidenceRow(aiEvidenceResult, "响应SHA256", evidence.response_sha256, "evidence-hash");
  }
  if (evidence.error) {
    appendEvidenceRow(aiEvidenceResult, "原因", evidence.error);
  }
  appendEvidenceRow(
    aiEvidenceResult,
    "说明",
    evidence.disclosure || "验证结果仅用于证明模型调用链可用。"
  );
  aiEvidenceResult.classList.remove("empty-state");
}

async function runAiSelfTest() {
  if (!state.serverOnline) {
    aiEvidenceResult.textContent = "在线服务端未连接，无法调用真实模型。离线模板不计为AI能力证据。";
    aiEvidenceResult.classList.add("empty-state");
    return;
  }
  aiSelfTestButton.disabled = true;
  aiSelfTestButton.textContent = "正在调用真实模型...";
  aiEvidenceResult.textContent = "正在执行固定提示词自检，请等待服务端返回真实推理结果。";
  aiEvidenceResult.classList.add("empty-state");
  try {
    const evidence = await apiRequest("/api/ai/self-test", {
      method: "POST",
      body: {}
    });
    state.lastAiEvidence = evidence;
    renderAiEvidence(evidence);
    downloadAiEvidenceButton.disabled = !evidence.verified;
  } catch (error) {
    state.lastAiEvidence = null;
    aiEvidenceResult.textContent = `AI能力自检失败：${error.message}`;
    aiEvidenceResult.classList.add("empty-state");
    downloadAiEvidenceButton.disabled = true;
  } finally {
    aiSelfTestButton.disabled = false;
    aiSelfTestButton.textContent = "验证真实 AI 能力";
  }
}

function downloadAiEvidence() {
  if (!state.lastAiEvidence) return;
  const blob = new Blob([JSON.stringify(state.lastAiEvidence, null, 2)], {
    type: "application/json;charset=utf-8"
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `AI能力验证证据_${state.lastAiEvidence.request_id || Date.now()}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

aiSelfTestButton.addEventListener("click", runAiSelfTest);
downloadAiEvidenceButton.addEventListener("click", downloadAiEvidence);

function renderAgentMetrics(metrics) {
  state.agentMetrics = metrics || null;
  agentStageMetric.textContent = String(metrics?.pipelineVersionAgents || 7);
  agentRunMetric.textContent = String(metrics?.total_runs ?? 0);
  agentOnlineMetric.textContent = `${Number(metrics?.online_evidence_rate ?? 0).toFixed(1)}%`;
  agentAuditMetric.textContent = Number(metrics?.average_audit_score ?? 0).toFixed(1);
}

function stageStatusLabel(status) {
  return ({
    completed: "完成",
    pass: "通过",
    fallback: "模板降级",
    needs_revision: "需修改",
    pending: "等待人工" 
  }[status] || status || "未知");
}

function renderAgentRun(run) {
  agentRunOutput.replaceChildren();
  agentRunOutput.classList.remove("empty-state");
  const online = run.generation?.mode === "online_model";
  const summary = createElement("div", "agent-run-summary");
  [
    ["运行状态", run.status === "pending_human_review" ? "待人工复核" : "需修改"],
    ["生成模式", online ? "真实模型在线生成" : "离线模板降级"],
    ["全链路 SHA256", run.bundle_sha256]
  ].forEach(([label, value]) => {
    const item = createElement("div");
    item.append(createElement("span", "", label), createElement("strong", label === "全链路 SHA256" ? "evidence-hash" : "", value));
    summary.append(item);
  });
  agentRunOutput.append(summary);
  const initialAudit = run.initial_audit || {};
  const finalAudit = run.audit || {};
  agentRunOutput.append(buildAuditComparison(
    initialAudit.score ?? 0,
    finalAudit.score ?? 0,
    Boolean(run.correction?.applied)
  ));

  const timeline = createElement("div", "stage-list");
  (run.stages || []).forEach((stage, index) => {
    const item = createElement("div", "stage-item");
    const marker = createElement("span", "stage-index", String(index + 1).padStart(2, "0"));
    const body = createElement("div");
    body.append(
      createElement("strong", "", `${stage.name} · ${stageStatusLabel(stage.status)}`),
      createElement("p", "", `${stage.role}｜${stage.capability}`),
      createElement("p", "", `耗时 ${Number(stage.latency_ms || 0).toFixed(1)} ms`) 
    );
    item.append(marker, body, createElement("code", "", String(stage.artifact_sha256 || "").slice(0, 12)));
    timeline.append(item);
  });
  agentRunOutput.append(timeline);

  const auditTitle = createElement("p", "result-meta", `证据审计 ${run.audit?.score ?? 0}/100｜有效引用 ${(run.audit?.valid_citations || []).join("、") || "无"}`);
  agentRunOutput.append(auditTitle);
  const checks = createElement("div", "audit-checks");
  (run.audit?.checks || []).forEach((check) => {
    const item = createElement("div", `audit-check ${check.passed ? "pass" : "fail"}`);
    item.append(createElement("span", "", check.label), createElement("strong", "", check.passed ? `通过｜${check.detail}` : `未通过｜${check.detail}`));
    checks.append(item);
  });
  agentRunOutput.append(checks);

  appendEvidenceRow(agentRunOutput, "运行编号", run.run_id);
  appendEvidenceRow(agentRunOutput, "生成请求", run.generation?.request_id || "-");
  appendEvidenceRow(agentRunOutput, "提供方 / 模型", `${run.generation?.provider || "-"} / ${run.generation?.model || "-"}`);
  appendEvidenceRow(agentRunOutput, "生成耗时", `${Number(run.generation?.latency_ms || 0).toFixed(1)} ms`);
  appendEvidenceRow(agentRunOutput, "响应 SHA256", run.generation?.response_sha256 || "-", "evidence-hash");
  appendEvidenceRow(agentRunOutput, "人工复核", run.status === "pending_human_review" ? "已进入待人工审核，禁止自动发布" : "审计未通过，需重新生成");
  if (run.audit?.risk_flags?.length) {
    appendEvidenceRow(agentRunOutput, "风险标记", run.audit.risk_flags.map((item) => item.detail).join("；"));
  }
  appendEvidenceRow(agentRunOutput, "生成初稿", run.generation?.response || "-", "evidence-response");

  agentRunState.textContent = online ? "真实模型已运行" : "模板降级";
  agentRunState.classList.toggle("tag-muted", !online);
}

async function runAgentWorkflow(event) {
  event.preventDefault();
  if (!state.serverOnline) {
    agentRunOutput.textContent = "多智能体证据链需要在线服务端和 SQLite。请先启动在线演示服务。";
    agentRunOutput.classList.add("empty-state");
    return;
  }
  runAgentPipelineButton.disabled = true;
  runAgentPipelineButton.textContent = "正在执行七个智能体阶段...";
  agentRunState.textContent = "运行中";
  agentRunState.classList.add("tag-muted");
  agentRunOutput.textContent = "正在检索知识、调用模型并执行证据审计，请等待服务端返回。";
  agentRunOutput.classList.add("empty-state");
  try {
    const run = await apiRequest("/api/agent/run", {
      method: "POST",
      body: {
        site_key: agentSiteSelect.value,
        goal: agentGoal.value.trim(),
        query: agentQuery.value.trim(),
        weather_check: true,
        privacy_check: true
      }
    });
    state.lastAgentRun = run;
    renderAgentRun(run);
    downloadAgentEvidenceButton.disabled = false;
    await loadAgentMetrics();
  } catch (error) {
    state.lastAgentRun = null;
    downloadAgentEvidenceButton.disabled = true;
    agentRunOutput.textContent = `多智能体运行失败：${error.message}`;
    agentRunOutput.classList.add("empty-state");
    agentRunState.textContent = "运行失败";
  } finally {
    runAgentPipelineButton.disabled = false;
    runAgentPipelineButton.textContent = "运行多智能体闭环";
  }
}

function downloadAgentEvidence() {
  if (!state.lastAgentRun) return;
  const payload = {
    report_type: "multi_agent_pipeline_evidence",
    exported_at: new Date().toISOString(),
    run: state.lastAgentRun
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `多智能体运行证据_${state.lastAgentRun.run_id}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

agentRunForm.addEventListener("submit", runAgentWorkflow);
downloadAgentEvidenceButton.addEventListener("click", downloadAgentEvidence);

function formatTime(value) {
  if (!value) return "未提供";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString("zh-CN", { hour12: false });
}

function renderSystemStatus(status) {
  systemStatusContent.replaceChildren();
  const model = status.model_service || {};
  const database = status.database || {};
  const pipeline = status.agent_pipeline || {};
  const rows = [
    ["多智能体闭环", `${pipeline.pipeline_version || "V2.0"}，${pipeline.total_runs ?? 0} 次运行，真实模型证据率 ${Number(pipeline.online_evidence_rate ?? 0).toFixed(1)}%`],
    ["运行模式", "在线服务"],
    ["服务版本", status.version || "未知"],
    ["服务器时间", formatTime(status.server_time)],
    ["数据存储", `${database.storage || "SQLite"}，${database.archive_count ?? 0} 条档案，${database.review_count ?? 0} 条审核`],
    ["模型服务", model.configured ? `${model.provider || "兼容服务"} / ${model.model || "未命名模型"}` : "未配置，使用离线模板"],
    ["AI生成模式", model.generation_mode === "online_model" ? "真实大模型生成" : "离线模板生成"],
    ["服务端密钥", model.server_side_key ? "已配置，不在浏览器保存" : "未配置"],
    ["访问控制", status.auth_enabled ? "Basic Auth 已启用" : "未启用演示账号"],
    ["公网地址", status.public_url || "尚未填写"],
    ["能力说明", model.disclosure || (status.ai_capability && status.ai_capability.disclosure) || "未提供"]
  ];

  rows.forEach(([label, value]) => {
    const row = createElement("div");
    row.append(createElement("span", "", label), createElement("strong", "", value));
    systemStatusContent.append(row);
  });
  renderDeploymentChecks(status);
}

function setOfflineStatus() {
  state.serverOnline = false;
  state.status = null;
  renderAgentMetrics({});
  renderDeploymentChecks(null);
  document.querySelector("#overviewStatusDot").classList.add("status-dot-offline");
  document.querySelector("#overviewStatusLabel").textContent = "离线演示模式";
  document.querySelector("#overviewStatusMeta").textContent = "规则规划、关键词检索、模板生成和三维展示可用";
  systemStatusContent.replaceChildren();
  const row = createElement("div");
  row.append(createElement("span", "", "运行模式"), createElement("strong", "", "离线文件模式"));
  const row2 = createElement("div");
  row2.append(createElement("span", "", "在线服务"), createElement("strong", "", "未连接"));
  systemStatusContent.append(row, row2);
}

async function connectServer() {
  if (location.protocol === "file:") {
    setOfflineStatus();
    renderOfflineArchives();
    return false;
  }

  try {
    const status = await apiRequest("/api/system/status");
    state.serverOnline = true;
    state.status = status;
    document.querySelector("#overviewStatusDot").classList.remove("status-dot-offline");
    document.querySelector("#overviewStatusLabel").textContent = "在线服务模式";
    document.querySelector("#overviewStatusMeta").textContent =
      `${status.database?.storage || "SQLite"} 已连接，${status.database?.archive_count ?? 0} 条档案`;
    renderSystemStatus(status);
    await loadArchives();
    await loadAgentMetrics();
    await loadShowcaseCases();
    return true;
  } catch (error) {
    console.warn("无法连接在线服务端。", error);
    setOfflineStatus();
    renderOfflineArchives();
    return false;
  }
}

function renderOfflineArchives() {
  archiveCount.textContent = "离线";
  archiveList.replaceChildren();
  const empty = createElement("div", "empty-state");
  empty.append(
    createElement("strong", "", "当前未连接档案数据库"),
    createElement("p", "", "启动在线演示服务后，可创建待审核档案并记录专家审核结论。")
  );
  archiveList.append(empty);
}

function renderArchives(archives) {
  archiveCount.textContent = `${archives.length} 条`;
  archiveList.replaceChildren();

  if (!archives.length) {
    const empty = createElement("div", "empty-state");
    empty.append(
      createElement("strong", "", "暂无档案"),
      createElement("p", "", "可在左侧提交第一条待审核档案。")
    );
    archiveList.append(empty);
    return;
  }

  archives.forEach((archive) => {
    const item = createElement("article", "archive-item");
    const header = createElement("div", "archive-item-header");
    const titleWrap = createElement("div");
    titleWrap.append(
      createElement("strong", "", archive.title),
      createElement("span", "muted", `${archive.site_name} · ${archive.created_by} · ${formatTime(archive.created_at)}`)
    );
    const statusTag = createElement(
      "span",
      `tag status-${archive.review_status}`,
      archive.review_status_label || archive.review_status
    );
    header.append(titleWrap, statusTag);

    const summary = createElement("p", "", archive.summary);
    const source = createElement("p", "archive-source", `资料来源：${archive.source}`);
    item.append(header, summary, source);

    if (archive.reviews && archive.reviews.length) {
      const history = createElement("div", "review-history");
      history.append(createElement("strong", "", "审核记录"));
      archive.reviews.forEach((review) => {
        const line = createElement("p", "", `${formatTime(review.created_at)} · ${review.reviewer} · ${review.comment || "无补充意见"}`);
        history.append(line);
      });
      item.append(history);
    }

    if (state.serverOnline) {
      const form = createElement("form", "review-box");
      form.dataset.archiveId = archive.id;
      const fields = createElement("div", "review-fields");
      const reviewer = createElement("input");
      reviewer.name = "reviewer";
      reviewer.placeholder = "审核人";
      reviewer.maxLength = 80;
      reviewer.required = true;
      const decision = createElement("select");
      decision.name = "decision";
      [
        ["", "选择审核结论"],
        ["approved", "审核通过"],
        ["changes_requested", "退回修改"],
        ["rejected", "审核不通过"]
      ].forEach(([value, label]) => {
        const option = createElement("option", "", label);
        option.value = value;
        decision.append(option);
      });
      decision.required = true;
      fields.append(reviewer, decision);
      const comment = createElement("textarea");
      comment.name = "comment";
      comment.rows = 2;
      comment.maxLength = 2000;
      comment.placeholder = "审核意见（可选，最多 2000 字）";
      const button = createElement("button", "button button-secondary", "提交审核");
      button.type = "submit";
      form.append(fields, comment, button);
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const submitButton = form.querySelector("button[type='submit']");
        submitButton.disabled = true;
        submitButton.textContent = "提交中...";
        try {
          await apiRequest(`/api/archives/${archive.id}/reviews`, {
            method: "POST",
            body: {
              reviewer: reviewer.value.trim(),
              decision: decision.value,
              comment: comment.value.trim()
            }
          });
          await loadArchives();
        } catch (error) {
          window.alert(`审核提交失败：${error.message}`);
          submitButton.disabled = false;
          submitButton.textContent = "提交审核";
        }
      });
      item.append(form);
    }

    archiveList.append(item);
  });
}

async function loadAgentMetrics() {
  if (!state.serverOnline) {
    renderAgentMetrics({});
    return;
  }
  try {
    renderAgentMetrics(await apiRequest("/api/agent/metrics"));
  } catch (error) {
    console.warn("读取多智能体指标失败。", error);
  }
}


async function loadArchives() {
  if (!state.serverOnline) {
    renderOfflineArchives();
    return;
  }
  try {
    const archives = await apiRequest("/api/archives");
    renderArchives(archives);
  } catch (error) {
    archiveCount.textContent = "读取失败";
    archiveList.replaceChildren(createElement("div", "empty-state", `读取档案失败：${error.message}`));
  }
}

archiveForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!state.serverOnline) {
    archiveFormState.textContent = "当前为离线模式。请先启动在线服务端，再提交档案。";
    return;
  }

  const submitButton = archiveForm.querySelector("button[type='submit']");
  submitButton.disabled = true;
  submitButton.textContent = "提交中...";
  archiveFormState.textContent = "正在写入 SQLite...";
  try {
    await apiRequest("/api/archives", {
      method: "POST",
      body: {
        site_key: document.querySelector("#archiveSite").value,
        title: document.querySelector("#archiveTitle").value.trim(),
        summary: document.querySelector("#archiveSummary").value.trim(),
        source: document.querySelector("#archiveSource").value.trim(),
        created_by: document.querySelector("#archiveCreatedBy").value.trim()
      }
    });
    archiveFormState.textContent = "提交成功，档案状态为待审核。";
    document.querySelector("#archiveTitle").value = "";
    document.querySelector("#archiveSummary").value = "";
    document.querySelector("#archiveSource").value = "";
    await loadArchives();
  } catch (error) {
    archiveFormState.textContent = `提交失败：${error.message}`;
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "提交待审核档案";
  }
});

systemStatusButton.addEventListener("click", () => systemDialog.showModal());
closeSystemDialogButton.addEventListener("click", () => systemDialog.close());
refreshStatusButton.addEventListener("click", async () => {
  refreshStatusButton.disabled = true;
  refreshStatusButton.textContent = "检测中...";
  await connectServer();
  refreshStatusButton.disabled = false;
  refreshStatusButton.textContent = "重新检测";
});
qrButton.addEventListener("click", () => qrDialog.showModal());
closeQrButton.addEventListener("click", () => qrDialog.close());

renderKnowledge(knowledgeBase.slice(0, 3), "offline");
renderVerifiedReviewEvidence();
renderShowcaseMatrix(showcaseFallback.cases);
connectServer();

if (new URLSearchParams(window.location.search).get("aiSelfTest") === "1") {
  window.setTimeout(async () => {
    if (!state.serverOnline) await connectServer();
    await runAiSelfTest();
  }, 600);
}
