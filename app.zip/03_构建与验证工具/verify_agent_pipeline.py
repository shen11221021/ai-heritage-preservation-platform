from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple


REPO_ROOT = Path(__file__).resolve().parents[1]
JSON_REPORT = REPO_ROOT / "AI多智能体评测报告.json"
MARKDOWN_REPORT = REPO_ROOT / "AI多智能体评测报告.md"
HEX_SHA256 = re.compile(r"^[0-9A-F]{64}$")
CASES = [
    {
        "case_id": "EVAL-01",
        "site_key": "lie-shishan",
        "goal": "完成工事遗址影像采集、三维模型复核和讲解初稿审核",
        "query": "工事走向 地形高差 影像采集 三维质检 人工审核",
    },
    {
        "case_id": "EVAL-02",
        "site_key": "qingxiang-wall",
        "goal": "形成标语墙病害记录、版权核验和可审核讲解初稿",
        "query": "标语墙 墙面纹理 结构裂缝 版权 人工审核",
    },
    {
        "case_id": "EVAL-03",
        "site_key": "langyu-caomaoshan",
        "goal": "形成山地遗址采集计划、模型质量复核和发布审核记录",
        "query": "山地遗址 植被遮挡 路径关系 三维模型质量 审核",
    },
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def request_json(
    base_url: str,
    path: str,
    method: str = "GET",
    body: Dict[str, Any] | None = None,
    timeout: float = 90.0,
) -> Dict[str, Any]:
    headers = {"Accept": "application/json", "Connection": "close"}
    data = None
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    request = urllib.request.Request(base_url.rstrip("/") + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        raise RuntimeError("{} {} 返回 {}：{}".format(method, path, error.code, detail[:500]))
    except urllib.error.URLError as error:
        raise RuntimeError("无法连接在线服务：{}".format(error.reason))
    if not isinstance(payload, dict) or payload.get("ok") is not True:
        raise RuntimeError("接口响应格式不正确：{}".format(payload))
    return payload


def validate_run(result: Dict[str, Any], expected_case: Dict[str, str]) -> Dict[str, Any]:
    if result.get("site_key") != expected_case["site_key"]:
        raise RuntimeError("{} 返回的遗址不匹配".format(expected_case["case_id"]))
    stages = result.get("stages") or []
    if len(stages) != 7:
        raise RuntimeError("{} 未形成七个智能体阶段".format(expected_case["case_id"]))
    generation = result.get("generation") or {}
    audit = result.get("audit") or {}
    if generation.get("mode") != "online_model":
        raise RuntimeError("{} 未调用真实模型，模式为 {}".format(expected_case["case_id"], generation.get("mode")))
    if not HEX_SHA256.match(str(generation.get("prompt_sha256", "")).upper()):
        raise RuntimeError("{} 提示词哈希无效".format(expected_case["case_id"]))
    if not HEX_SHA256.match(str(generation.get("response_sha256", "")).upper()):
        raise RuntimeError("{} 响应哈希无效".format(expected_case["case_id"]))
    if int(audit.get("score", 0)) < 80:
        raise RuntimeError("{} 证据审计分数低于80：{}".format(expected_case["case_id"], audit.get("score")))
    if len(audit.get("valid_citations") or []) < 2:
        raise RuntimeError("{} 有效引用不足两个".format(expected_case["case_id"]))
    if "applied" not in (result.get("correction") or {}):
        raise RuntimeError("{} 未记录纠错智能体处理过程".format(expected_case["case_id"]))
    if result.get("status") != "pending_human_review":
        raise RuntimeError("{} 未进入人工复核闸门".format(expected_case["case_id"]))
    if not HEX_SHA256.match(str(result.get("bundle_sha256", "")).upper()):
        raise RuntimeError("{} 全链路哈希无效".format(expected_case["case_id"]))
    return {
        "case_id": expected_case["case_id"],
        "site_key": expected_case["site_key"],
        "status": result.get("status"),
        "run_id": result.get("run_id"),
        "generation_mode": generation.get("mode"),
        "provider": generation.get("provider"),
        "model": generation.get("model"),
        "generation_request_id": generation.get("request_id"),
        "generation_latency_ms": generation.get("latency_ms"),
        "pipeline_latency_ms": result.get("latency_ms"),
        "prompt_sha256": generation.get("prompt_sha256"),
        "response_sha256": generation.get("response_sha256"),
        "bundle_sha256": result.get("bundle_sha256"),
        "audit_score": audit.get("score"),
        "initial_audit_score": (result.get("initial_audit") or {}).get("score"),
        "initial_audit_status": (result.get("initial_audit") or {}).get("status"),
        "correction_applied": (result.get("correction") or {}).get("applied"),
        "final_audit_score": audit.get("score"),
        "valid_citations": audit.get("valid_citations"),
        "risk_flags": audit.get("risk_flags"),
        "response": generation.get("response"),
    }


def make_markdown(report: Dict[str, Any]) -> str:
    lines = [
        "# AI多智能体真实模型评测报告",
        "",
        "- 版本：V2.0",
        "- 评测时间：{}".format(report["generated_at"]),
        "- 服务地址：{}".format(report["base_url"]),
        "- 总体结果：{}".format("通过" if report["ok"] else "未通过"),
        "- 真实模型运行：{} / {} 例通过".format(report["passed"], report["total"]),
        "",
        "| 用例 | 模型 | 初审分 | 纠错 | 终审分 | 引用 | 生成耗时 | 响应SHA256 | 全链路SHA256 |",
        "|---|---|---:|---|---:|---|---:|---|---|",
    ]
    for case in report["cases"]:
        lines.append(
            "| {case_id} | {model} | {initial_audit_score} | {correction} | {audit_score} | {citations} | {latency:.2f} ms | `{response_sha256}` | `{bundle_sha256}` |".format(
                case_id=case["case_id"],
                model=case.get("model") or "-",
                initial_audit_score=case.get("initial_audit_score"),
                correction="是" if case.get("correction_applied") else "否",
                audit_score=case.get("audit_score"),
                citations="、".join(case.get("valid_citations") or []),
                latency=float(case.get("generation_latency_ms") or 0),
                response_sha256=case.get("response_sha256") or "-",
                bundle_sha256=case.get("bundle_sha256") or "-",
            )
        )
    lines.extend(
        [
            "",
            "## 证据边界",
            "",
            "- 三次调用均由服务端真实模型完成，不是浏览器离线模板。",
            "- 每个用例均经过输入守卫、知识检索、任务规划、AIGC生成、证据审计、纠错重写和人工复核七个阶段。",
            "- 模型原始输出单独保留为证据，平台只将通过审计或完成纠错的安全稿送入人工复核。",
            "- 审计通过只说明引用、边界和风险检查通过，不代表历史事实已由专家确认。",
            "- 所有运行均为 `pending_human_review`，禁止自动发布。",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Run and record real-model multi-agent benchmark evidence.")
    parser.add_argument("--base-url", default="http://127.0.0.1:8080")
    parser.add_argument("--output-json", type=Path, default=JSON_REPORT)
    parser.add_argument("--output-markdown", type=Path, default=MARKDOWN_REPORT)
    parser.add_argument("--write", action="store_true", help="Write formal JSON and Markdown evidence files.")
    args = parser.parse_args()

    started = time.perf_counter()
    report: Dict[str, Any] = {
        "service": "HeritageMultiAgentEvaluation",
        "version": "V2.0",
        "generated_at": utc_now(),
        "base_url": args.base_url.rstrip("/"),
        "ok": False,
        "passed": 0,
        "total": len(CASES),
        "cases": [],
        "error": "",
    }
    try:
        for case in CASES:
            payload = request_json(
                args.base_url,
                "/api/agent/run",
                method="POST",
                body={
                    "site_key": case["site_key"],
                    "goal": case["goal"],
                    "query": case["query"],
                    "weather_check": True,
                    "privacy_check": True,
                },
            )
            report["cases"].append(validate_run(payload["data"], case))
        report["passed"] = len(report["cases"])
        report["ok"] = report["passed"] == report["total"]
    except Exception as error:
        report["error"] = str(error)
    report["duration_ms"] = round((time.perf_counter() - started) * 1000, 2)
    report["report_sha256"] = hashlib.sha256(
        json.dumps(report, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest().upper()

    if args.write:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        args.output_markdown.write_text(make_markdown(report), encoding="utf-8")

    print("RESULT: {} ({}/{} cases passed)".format("PASS" if report["ok"] else "FAIL", report["passed"], report["total"]))
    if report["error"]:
        print("ERROR:", report["error"])
    for case in report["cases"]:
        print(
            "{}: {} / audit={} / citations={} / {} ms".format(
                case["case_id"],
                case["model"],
                case["audit_score"],
                ",".join(case["valid_citations"] or []),
                case["generation_latency_ms"],
            )
        )
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
