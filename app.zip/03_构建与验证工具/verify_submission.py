﻿from __future__ import annotations

import argparse
import contextlib
import hashlib
import base64
import json
import os
import re
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


REPO_ROOT = Path(__file__).resolve().parents[1]
SERVER = REPO_ROOT / "04_在线服务端" / "server.py"
AI_EVIDENCE_RECORD = REPO_ROOT / "AI能力验证报告.json"
FRONTEND = REPO_ROOT / "01_平台前端"
SHOWCASE_RECORD = FRONTEND / "assets" / "showcase-cases.json"
CASES = REPO_ROOT / "02_三维案例源码"
SUBMISSION_ROOT = REPO_ROOT.parent
SOURCE_ZIP = SUBMISSION_ROOT / "作品源代码.zip"
SUBMISSION_ATTACHMENTS = [
    SUBMISSION_ROOT / "作品简介.pdf",
    SUBMISSION_ROOT / "作品简介图1.png",
    SUBMISSION_ROOT / "作品简介图2.png",
    SUBMISSION_ROOT / "作品简介图3.png",
    SUBMISSION_ROOT / "AI智能体驱动的基层红色遗址保护平台软件设计文档.pdf",
    SOURCE_ZIP,
    SUBMISSION_ROOT / "软件安装包.zip",
    SUBMISSION_ROOT / "AI智能体驱动的基层红色遗址保护平台演示视频.mp4",
]

REQUIRED_FILES = [
    REPO_ROOT / "README.md",
    REPO_ROOT / "运行说明.md",
    REPO_ROOT / "部署说明.md",
    REPO_ROOT / "原创代码说明.md",
    REPO_ROOT / "第三方开源代码清单.md",
    REPO_ROOT / "AI能力验证报告.md",
    AI_EVIDENCE_RECORD,
    REPO_ROOT / "03_构建与验证工具" / "verify_ai_capability.py",
    REPO_ROOT / "03_构建与验证工具" / "verify_agent_pipeline.py",
    REPO_ROOT / "04_在线服务端" / "agent_pipeline.py",
    REPO_ROOT / "AI多智能体评测报告.json",
    REPO_ROOT / "AI多智能体评测报告.md",
    REPO_ROOT / "Dockerfile",
    REPO_ROOT / "render.yaml",
    FRONTEND / "index.html",
    FRONTEND / "index.css",
    FRONTEND / "index.js",
    FRONTEND / "assets" / "lie-shishan-preview.png",
    FRONTEND / "assets" / "qingxiang-slogan-wall-preview.png",
    FRONTEND / "assets" / "langyu-caomaoshan-preview.png",
    FRONTEND / "assets" / "runtime-desktop.png",
    FRONTEND / "assets" / "runtime-mobile.png",
    SHOWCASE_RECORD,
    CASES / "烈石山工事遗址.html",
    CASES / "勍香镇红色标语墙遗址.html",
    CASES / "狼峪草帽山遗址.html",
    SERVER,
]

EXPECTED_CASE_MARKERS = {
    CASES / "烈石山工事遗址.html": ["烈石山工事遗址", "canvas", "GLB", "model/gltf-binary"],
    CASES / "勍香镇红色标语墙遗址.html": ["勍香镇红色标语墙遗址", "canvas", "GLB", "model/gltf-binary"],
    CASES / "狼峪草帽山遗址.html": ["狼峪草帽山", "canvas", "GLB", "model/gltf-binary"],
}


class VerificationFailure(RuntimeError):
    pass


class Checks:
    def __init__(self) -> None:
        self.items: List[Dict[str, Any]] = []

    def run(self, name: str, function) -> Any:
        started = time.perf_counter()
        try:
            detail = function()
            self.items.append(
                {
                    "name": name,
                    "ok": True,
                    "detail": detail if detail is not None else "通过",
                    "elapsed_ms": round((time.perf_counter() - started) * 1000, 2),
                }
            )
            return detail
        except Exception as error:
            self.items.append(
                {
                    "name": name,
                    "ok": False,
                    "detail": str(error),
                    "elapsed_ms": round((time.perf_counter() - started) * 1000, 2),
                }
            )
            raise

    @property
    def failed(self) -> List[Dict[str, Any]]:
        return [item for item in self.items if not item["ok"]]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationFailure(message)


def decode_json(raw: bytes) -> Dict[str, Any]:
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise VerificationFailure("响应不是有效 UTF-8 JSON：{}".format(error))
    require(isinstance(payload, dict), "JSON 响应根节点必须是对象")
    return payload


def http_request(
    base_url: str,
    path: str,
    method: str = "GET",
    body: Optional[Dict[str, Any]] = None,
    username: str = "",
    password: str = "",
    timeout: float = 30.0,
) -> Tuple[int, Dict[str, str], bytes]:
    headers = {"Accept": "application/json", "Connection": "close"}
    if username or password:
        token = base64.b64encode("{}:{}".format(username, password).encode("utf-8")).decode("ascii")
        headers["Authorization"] = "Basic {}".format(token)
    data = None
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    encoded_path = urllib.parse.quote(path, safe="/?=&%")
    request = urllib.request.Request(base_url + encoded_path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            response_headers = {key.lower(): value for key, value in response.headers.items()}
            return response.status, response_headers, response.read()
    except urllib.error.HTTPError as error:
        error_headers = {key.lower(): value for key, value in error.headers.items()}
        return error.code, error_headers, error.read()


def json_request(
    base_url: str,
    path: str,
    method: str = "GET",
    body: Optional[Dict[str, Any]] = None,
    username: str = "",
    password: str = "",
    expected_status: int = 200,
) -> Dict[str, Any]:
    status, _headers, raw = http_request(base_url, path, method, body, username, password)
    require(status == expected_status, "{} {} 返回 {}，预期 {}".format(method, path, status, expected_status))
    return decode_json(raw)


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def wait_for_server(base_url: str, process: subprocess.Popen, log_path: Path) -> None:
    deadline = time.time() + 20
    while time.time() < deadline:
        if process.poll() is not None:
            log = log_path.read_text(encoding="utf-8", errors="replace") if log_path.exists() else ""
            raise VerificationFailure("服务端提前退出，退出码 {}。日志：{}".format(process.returncode, log[-2000:]))
        try:
            status, _headers, raw = http_request(base_url, "/api/health", timeout=1)
            if status == 200 and decode_json(raw).get("ok") is True:
                return
        except Exception:
            pass
        time.sleep(0.2)
    raise VerificationFailure("等待服务端启动超时")


def verify_required_files() -> str:
    missing = [str(path.relative_to(REPO_ROOT)) for path in REQUIRED_FILES if not path.is_file()]
    require(not missing, "缺少必要文件：{}".format("、".join(missing)))
    tiny = [str(path.relative_to(REPO_ROOT)) for path in REQUIRED_FILES if path.stat().st_size < 32]
    require(not tiny, "文件内容异常偏小：{}".format("、".join(tiny)))
    return "{} 个必要文件齐全".format(len(REQUIRED_FILES))


def verify_frontend_offline() -> str:
    html = (FRONTEND / "index.html").read_text(encoding="utf-8")
    javascript = (FRONTEND / "index.js").read_text(encoding="utf-8")
    css = (FRONTEND / "index.css").read_text(encoding="utf-8")
    required_markers = [
        "智能体工作台",
        "照片质量预检",
        "知识检索与讲解生成",
        "三处遗址三维展示",
        "遗址档案与专家审核",
        "systemStatusButton",
        "aiSelfTestButton",
        "archiveForm",
        "agentRunForm",
        "多智能体闭环与可追溯证据",
        "移动端与浏览器运行效果",
        "部署与档案审核门禁",
        "EVAL-01 真实模型运行回放",
        "可演示案例矩阵",
        "siteCaseGrid",
        "businessCaseGrid",
        "caseDialog",
        "caseVerifyButton",
    ]
    for marker in required_markers:
        require(marker in html, "前端入口缺少功能标记：{}".format(marker))
    require("apiRequest(\"/api/system/status\")" in javascript, "前端未检测在线服务端")
    require("localSearch" in javascript and "buildOfflineStory" in javascript, "前端缺少离线兜底逻辑")
    require("analyzePixels" in javascript and "renderImageResult" in javascript, "前端缺少照片质量预检逻辑")
    require("runAgentWorkflow" in javascript and "renderAgentRun" in javascript, "前端缺少多智能体运行与证据展示逻辑")
    require("showcaseMaterial" in javascript and "verifyShowcaseCase" in javascript, "前端缺少案例证据核验逻辑")
    require("fetch(" in javascript and "credentials: \"same-origin\"" in javascript, "前端接口调用设置不正确")
    require("settingsButton" not in css, "CSS 仍包含无效的 settingsButton 选择器")

    external_urls = re.findall(r"(?:src|href)=[\"'](https?://[^\"']+)", html, flags=re.IGNORECASE)
    external_urls += re.findall(r"url\([\"']?(https?://[^\"')]+)", css, flags=re.IGNORECASE)
    require(not external_urls, "前端存在外部运行依赖：{}".format("、".join(external_urls)))
    return "前端功能入口、离线降级和同源接口检查通过"


def verify_model_cases() -> str:
    details = []
    for path, markers in EXPECTED_CASE_MARKERS.items():
        size = path.stat().st_size
        require(size >= 1024 * 1024, "{} 小于 1 MB，可能不是完整模型页".format(path.name))
        content = path.read_text(encoding="utf-8", errors="replace")
        missing = [marker for marker in markers if marker not in content]
        require(not missing, "{} 缺少标记：{}".format(path.name, "、".join(missing)))
        require("data:model/gltf-binary;base64" in content or "model/gltf-binary" in content, "{} 未内嵌 GLB".format(path.name))
        details.append("{} {:.2f} MB".format(path.name, size / 1024 / 1024))
    return "三套案例通过：" + "；".join(details)


def verify_showcase_record() -> str:
    payload = json.loads(SHOWCASE_RECORD.read_text(encoding="utf-8"))
    cases = payload.get("cases") if isinstance(payload, dict) else None
    require(isinstance(cases, list) and len(cases) == 6, "案例矩阵必须包含 6 条案例")
    site_cases = [item for item in cases if item.get("group") == "site"]
    business_cases = [item for item in cases if item.get("group") == "business"]
    require(len(site_cases) == 3 and len(business_cases) == 3, "案例矩阵必须为 3 个遗址实例 + 3 个业务案例")
    for item in cases:
        for field in ("id", "title", "site_key", "input", "output", "integrity_sha256", "target"):
            require(item.get(field) not in (None, ""), "案例 {} 缺少字段 {}".format(item.get("id", "?"), field))
        require(len(item.get("ai_steps", [])) >= 3, "案例 {} 的 AI 环节不足".format(item["id"]))
        review = item.get("review") or {}
        for field in ("record_id", "reviewer", "decision", "detail"):
            require(review.get(field), "案例 {} 缺少人工复核字段 {}".format(item["id"], field))
        material = "\n".join(
            [
                str(item.get("id", "")),
                str(item.get("title", "")),
                str(item.get("site_key", "")),
                str(item.get("input", "")),
                " | ".join(str(entry) for entry in item.get("ai_steps", [])),
                str(item.get("output", "")),
                str(review.get("record_id", "")),
                str(review.get("reviewer", "")),
                str(review.get("decision", "")),
                str(review.get("detail", "")),
                " | ".join(str(entry) for entry in item.get("evidence_refs", [])),
            ]
        )
        expected = hashlib.sha256(material.encode("utf-8")).hexdigest().upper()
        require(expected == item["integrity_sha256"], "案例 {} 登记摘要与字段不匹配".format(item["id"]))
    return "3 个遗址实例 + 3 个业务案例，6/6 摘要核验通过"


def verify_ai_evidence_record() -> str:
    require(AI_EVIDENCE_RECORD.is_file(), "缺少 AI 能力机器可读报告")
    evidence = json.loads(AI_EVIDENCE_RECORD.read_text(encoding="utf-8"))
    require(evidence.get("status") == "verified" and evidence.get("verified") is True, "AI 能力报告未通过验证")
    for field in ("request_id", "provider", "model", "prompt", "response", "latency_ms"):
        require(evidence.get(field) not in (None, ""), "AI 能力报告缺少字段：{}".format(field))
    prompt = str(evidence["prompt"])
    response = str(evidence["response"])
    require(response.startswith("AI可辅助"), "AI 能力报告响应未满足固定提示词要求")
    prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest().upper()
    response_hash = hashlib.sha256(response.encode("utf-8")).hexdigest().upper()
    require(evidence.get("prompt_sha256") == prompt_hash, "AI 能力报告提示词 SHA256 不匹配")
    require(evidence.get("response_sha256") == response_hash, "AI 能力报告响应 SHA256 不匹配")
    return "{} / {} / {} ms".format(evidence["provider"], evidence["model"], evidence["latency_ms"])


def verify_api(base_url: str, username: str, password: str) -> Dict[str, int]:
    health = json_request(base_url, "/api/health")
    require(health.get("ok") is True and health.get("status") == "online", "健康检查响应不正确")

    unauthorized = json_request(
        base_url,
        "/api/system/status",
        expected_status=401,
    )
    require(unauthorized.get("ok") is False, "未认证请求不应返回业务数据")

    status = json_request(base_url, "/api/system/status", username=username, password=password)
    require(status.get("ok") is True, "系统状态接口失败")
    require(status["data"].get("version") == "V2.0", "服务端版本不是 V2.0")
    require(status["data"].get("agent_pipeline", {}).get("pipeline_version") == "2.0", "多智能体运行指标未接入系统状态")
    require(status["data"].get("auth_enabled") is True, "Basic Auth 未生效")
    require(status["data"].get("database", {}).get("ready") is True, "SQLite 未就绪")

    ai_status = json_request(base_url, "/api/ai/status", username=username, password=password)
    require(ai_status.get("ok") is True, "AI能力状态接口失败")
    ai_data = ai_status.get("data") or {}
    require(ai_data.get("generation_mode") == "offline_template", "未配置模型时AI模式应为offline_template")
    require(ai_data.get("model_configured") is False, "未配置模型时不应报告模型已配置")
    require(bool(ai_data.get("disclosure")), "AI能力披露不能为空")

    self_test = json_request(
        base_url,
        "/api/ai/self-test",
        method="POST",
        body={},
        username=username,
        password=password,
    )
    self_test_data = self_test.get("data") or {}
    require(self_test_data.get("status") == "not_configured", "未配置模型时自检状态应为not_configured")
    require(self_test_data.get("verified") is False, "未配置模型时不得生成虚假AI证据")
    require(self_test_data.get("request_id"), "AI能力自检缺少请求编号")

    plan = json_request(
        base_url,
        "/api/plan",
        method="POST",
        body={
            "site_key": "lie-shishan",
            "goal": "完成现场采集、模型复核和讲解审核",
            "weather_check": True,
            "privacy_check": True,
        },
        username=username,
        password=password,
    )
    require(len(plan["data"].get("steps", [])) >= 7, "智能体任务计划步骤不足")

    agent_manifest = json_request(
        base_url,
        "/api/agent/manifest",
        username=username,
        password=password,
    )
    require(len(agent_manifest["data"].get("agents", [])) == 7, "多智能体清单不是七个阶段")

    showcase = json_request(base_url, "/api/showcase/cases", username=username, password=password)
    showcase_cases = showcase["data"].get("cases", [])
    require(len(showcase_cases) == 6, "案例矩阵接口未返回 6 条案例")
    require(sum(item.get("group") == "site" for item in showcase_cases) == 3, "案例矩阵遗址实例不足 3 条")
    require(sum(item.get("group") == "business" for item in showcase_cases) == 3, "案例矩阵业务案例不足 3 条")
    for case in showcase_cases:
        verified_case = json_request(
            base_url,
            "/api/showcase/verify",
            method="POST",
            body={"case_id": case["id"]},
            username=username,
            password=password,
        )
        require(verified_case["data"].get("verified") is True, "{} 证据核验未通过".format(case["id"]))
        require(len(verified_case["data"].get("recomputed_sha256", "")) == 64, "{} 核验摘要无效".format(case["id"]))

    agent_run = json_request(
        base_url,
        "/api/agent/run",
        method="POST",
        body={
            "site_key": "qingxiang-wall",
            "goal": "完成现场采集、讲解初稿和人工审核",
            "query": "标语墙 影像采集 版权和人工审核",
        },
        username=username,
        password=password,
    )
    agent_data = agent_run["data"]
    require(len(agent_data.get("stages", [])) == 7, "多智能体运行未形成七个阶段证据")
    require(agent_data.get("generation", {}).get("mode") == "offline_template", "未配置模型时多智能体应明确降级为模板")
    require(agent_data.get("audit", {}).get("score", 0) >= 80, "多智能体证据审计分数过低")
    require(len(agent_data.get("audit", {}).get("valid_citations", [])) >= 2, "多智能体引用证据不足")
    require("initial_audit" in agent_data and "final_audit" in agent_data.get("correction", {}), "多智能体缺少初审或终审证据")
    require(agent_data.get("correction", {}).get("final_audit", {}).get("score", 0) >= agent_data.get("initial_audit", {}).get("score", 0), "纠错终审分数低于初审分数")
    require(agent_data.get("status") == "pending_human_review", "多智能体结果未进入人工复核")
    require(len(agent_data.get("bundle_sha256", "")) == 64, "多智能体全链路证据哈希无效")

    agent_metrics = json_request(
        base_url,
        "/api/agent/metrics",
        username=username,
        password=password,
    )
    require(agent_metrics["data"].get("total_runs", 0) >= 1, "多智能体运行记录未写入数据库")

    invalid_plan = json_request(
        base_url,
        "/api/plan",
        method="POST",
        body={"site_key": "unknown-site", "goal": "test"},
        username=username,
        password=password,
        expected_status=400,
    )
    require(invalid_plan.get("ok") is False, "未知遗址未返回错误")

    knowledge = json_request(
        base_url,
        "/api/knowledge/search",
        method="POST",
        body={"query": "照片清晰度和模型纹理"},
        username=username,
        password=password,
    )
    require(knowledge["data"].get("entries"), "知识检索未返回结果")

    generated = json_request(
        base_url,
        "/api/ai/generate",
        method="POST",
        body={"site_key": "qingxiang-wall", "query": "标语墙数字化讲解"},
        username=username,
        password=password,
    )
    require(generated["data"].get("mode") == "offline_template", "未配置模型时应使用离线模板")
    require("待审核" in generated["data"].get("content", ""), "生成初稿未标记待审核")

    invalid_archive = json_request(
        base_url,
        "/api/archives",
        method="POST",
        body={"site_key": "lie-shishan"},
        username=username,
        password=password,
        expected_status=400,
    )
    require(invalid_archive.get("ok") is False, "无效档案未返回错误")

    created = json_request(
        base_url,
        "/api/archives",
        method="POST",
        body={
            "site_key": "lie-shishan",
            "title": "自动化验收档案",
            "summary": "用于验证档案创建、审核状态和导出流程，不包含真实历史事实。",
            "source": "verify_submission.py 自动化测试",
            "created_by": "验收脚本",
        },
        username=username,
        password=password,
        expected_status=201,
    )
    archive_id = int(created["data"]["id"])
    require(created["data"]["review_status"] == "pending", "新档案状态不是待审核")

    reviewed = json_request(
        base_url,
        "/api/archives/{}/reviews".format(archive_id),
        method="POST",
        body={"decision": "approved", "reviewer": "测试审核人", "comment": "自动化验收通过"},
        username=username,
        password=password,
    )
    require(reviewed["data"]["review_status"] == "approved", "审核状态未更新")
    require(len(reviewed["data"].get("reviews", [])) == 1, "审核记录未保存")

    archives = json_request(base_url, "/api/archives", username=username, password=password)
    require(any(item.get("id") == archive_id for item in archives["data"]), "档案列表中找不到新建档案")

    exported = json_request(base_url, "/api/export/archives", username=username, password=password)
    require(exported.get("exported_at"), "档案导出缺少时间戳")
    require(exported.get("data"), "档案导出内容为空")

    status_after = json_request(base_url, "/api/system/status", username=username, password=password)
    require(status_after["data"]["database"]["archive_count"] >= 1, "状态统计未反映新建档案")
    require(status_after["data"]["database"]["review_count"] >= 1, "状态统计未反映审核记录")

    index_status, headers, _raw = http_request(
        base_url,
        "/01_平台前端/index.html",
        username=username,
        password=password,
    )
    require(index_status == 200, "前端入口无法通过服务端访问")
    require("text/html" in headers.get("content-type", ""), "前端入口不是 HTML")
    require(headers.get("x-content-type-options") == "nosniff", "缺少安全响应头")

    for case_name in (
        "烈石山工事遗址.html",
        "勍香镇红色标语墙遗址.html",
        "狼峪草帽山遗址.html",
    ):
        case_status, case_headers, _body = http_request(
            base_url,
            "/02_三维案例源码/" + case_name,
            method="HEAD",
            username=username,
            password=password,
        )
        require(case_status == 200, "{} 无法访问".format(case_name))
        require(int(case_headers.get("content-length", "0")) > 1024 * 1024, "{} 响应大小异常".format(case_name))

    missing_status, _headers, _raw = http_request(
        base_url,
        "/api/not-found",
        username=username,
        password=password,
    )
    require(missing_status == 404, "未知 API 未返回 404")

    return {
        "plan_steps": len(plan["data"]["steps"]),
        "knowledge_entries": len(knowledge["data"]["entries"]),
        "archive_id": archive_id,
        "agent_stages": len(agent_data.get("stages", [])),
        "agent_audit_score": agent_data.get("audit", {}).get("score"),
        "agent_runs": agent_metrics["data"].get("total_runs"),
        "showcase_cases": len(showcase_cases),
        "showcase_verified": True,
        "archive_count": int(status_after["data"]["database"]["archive_count"]),
        "review_count": int(status_after["data"]["database"]["review_count"]),
    }


def verify_source_zip() -> str:
    require(SOURCE_ZIP.is_file(), "未找到 {}".format(SOURCE_ZIP))
    with zipfile.ZipFile(SOURCE_ZIP, "r") as archive:
        names = archive.namelist()
        bad_entry = archive.testzip()
    require(bad_entry is None, "ZIP 损坏：{}".format(bad_entry))
    required_names = {
        "AI能力验证报告.md",
        "AI能力验证报告.json",
        "README.md",
        "01_平台前端/index.html",
        "01_平台前端/index.css",
        "01_平台前端/index.js",
        "01_平台前端/assets/showcase-cases.json",
        "02_三维案例源码/烈石山工事遗址.html",
        "02_三维案例源码/勍香镇红色标语墙遗址.html",
        "02_三维案例源码/狼峪草帽山遗址.html",
        "03_构建与验证工具/verify_submission.py",
        "03_构建与验证工具/verify_ai_capability.py",
        "03_构建与验证工具/verify_agent_pipeline.py",
        "04_在线服务端/agent_pipeline.py",
        "AI多智能体评测报告.json",
        "AI多智能体评测报告.md",
        "04_在线服务端/server.py",
    }
    missing = sorted(required_names.difference(names))
    require(not missing, "源码 ZIP 缺少：{}".format("、".join(missing)))
    forbidden_parts = (".env", "heritage.db", "__pycache__", "work", "data", ".git")
    forbidden = []
    for name in names:
        parts = name.replace("\\", "/").split("/")
        if any(part in forbidden_parts for part in parts) or name.endswith((".pyc", ".pyo")):
            forbidden.append(name)
    require(not forbidden, "源码 ZIP 含运行时或敏感文件：{}".format("、".join(forbidden[:8])))
    return "{}，共 {} 个文件".format(SOURCE_ZIP.name, len(names))


def verify_submission_attachments() -> str:
    details = []
    for path in SUBMISSION_ATTACHMENTS:
        require(path.is_file(), "缺少官方提交附件：{}".format(path.name))
        require(path.stat().st_size > 1024, "提交附件过小：{}".format(path.name))
        details.append("{} {:.2f} MB".format(path.name, path.stat().st_size / 1024 / 1024))

    for pdf_name in ("作品简介.pdf", "AI智能体驱动的基层红色遗址保护平台软件设计文档.pdf"):
        path = SUBMISSION_ROOT / pdf_name
        require(path.read_bytes()[:5] == b"%PDF-", "{} 不是有效PDF文件".format(pdf_name))

    video = SUBMISSION_ROOT / "AI智能体驱动的基层红色遗址保护平台演示视频.mp4"
    video_header = video.read_bytes()[:32]
    require(b"ftyp" in video_header, "演示视频不是有效的MP4容器")

    forbidden = []
    for archive_path in (SOURCE_ZIP, SUBMISSION_ROOT / "软件安装包.zip"):
        with zipfile.ZipFile(archive_path) as archive:
            for name in archive.namelist():
                parts = name.replace("\\", "/").split("/")
                if any(part in {".env", "heritage.db", "__pycache__", "work", "data", ".git"} for part in parts):
                    forbidden.append("{}: {}".format(archive_path.name, name))
                if name.endswith((".pyc", ".pyo")) or "~$" in name:
                    forbidden.append("{}: {}".format(archive_path.name, name))
    require(not forbidden, "提交压缩包含临时或敏感文件：{}".format("；".join(forbidden[:8])))
    return "；".join(details)


def markdown_report(report: Dict[str, Any]) -> str:
    lines = [
        "# 源代码自动化验收报告",
        "",
        "- 作品：AI智能体驱动的基层红色遗址保护平台",
        "- 版本：V2.0",
        "- 验收时间：{}".format(report["finished_at"]),
        "- 总体结果：{}".format("通过" if report["ok"] else "未通过"),
        "- 通过检查：{}/{}".format(report["passed"], report["total"]),
        "",
        "| 检查项 | 结果 | 说明 |",
        "|---|---|---|",
    ]
    for item in report["checks"]:
        detail = str(item["detail"]).replace("|", "\\|").replace("\n", " ")
        lines.append("| {} | {} | {} |".format(item["name"], "通过" if item["ok"] else "失败", detail))
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify the complete runnable source submission.")
    parser.add_argument("--report", type=Path, help="Write a JSON verification report.")
    parser.add_argument("--markdown", type=Path, help="Write a Markdown verification report.")
    parser.add_argument("--zip", action="store_true", help="Also verify D:\\华北\\作品源代码.zip.")
    parser.add_argument("--submission", action="store_true", help="Verify all official submission attachments under D:\\华北.")
    args = parser.parse_args()

    started = datetime.now(timezone.utc)
    checks = Checks()
    server_report: Dict[str, Any] = {}
    process: Optional[subprocess.Popen] = None
    (REPO_ROOT / "work").mkdir(parents=True, exist_ok=True)
    temp = REPO_ROOT / "work" / "verification-runtime-{}-{}".format(os.getpid(), int(time.time()))
    temp.mkdir(parents=True, exist_ok=True)
    with contextlib.nullcontext():
        log_path = temp / "server.log"
        port = find_free_port()
        base_url = "http://127.0.0.1:{}".format(port)
        username = "submission-verifier"
        password = "local-verification-only"
        env = os.environ.copy()
        env.update(
            {
                "PYTHONIOENCODING": "utf-8",
                "HERITAGE_HOST": "127.0.0.1",
                "HERITAGE_PORT": str(port),
                "HERITAGE_DB_PATH": str(temp / "verification.db"),
                "HERITAGE_PUBLIC_URL": "https://example.invalid/heritage",
                "HERITAGE_BASIC_USER": username,
                "HERITAGE_BASIC_PASSWORD": password,
                "HERITAGE_LLM_PROVIDER": "",
                "HERITAGE_LLM_ENDPOINT": "",
                "HERITAGE_LLM_MODEL": "",
                "HERITAGE_LLM_API_KEY": "",
            }
        )
        try:
            checks.run("必要文件与目录结构", verify_required_files)
            checks.run("前端离线能力与同源接口", verify_frontend_offline)
            checks.run("三处三维案例完整性", verify_model_cases)
            checks.run("3 + 3 可演示案例矩阵", verify_showcase_record)
            checks.run("真实 AI 能力证据记录", verify_ai_evidence_record)

            with log_path.open("wb") as log_file:
                process = subprocess.Popen(
                    [sys.executable, str(SERVER)],
                    cwd=str(REPO_ROOT),
                    env=env,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
            checks.run("在线服务端启动", lambda: wait_for_server(base_url, process, log_path))
            server_report = checks.run("服务端 API 与业务闭环", lambda: verify_api(base_url, username, password))
            if args.zip:
                checks.run("源码 ZIP 结构与敏感文件", verify_source_zip)
            if args.submission:
                checks.run("官方提交附件与安装包", verify_submission_attachments)
        except Exception:
            pass
        finally:
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)

    finished = datetime.now(timezone.utc)
    report = {
        "name": "AI智能体驱动的基层红色遗址保护平台",
        "version": "V2.0",
        "started_at": started.isoformat(timespec="seconds"),
        "finished_at": finished.isoformat(timespec="seconds"),
        "ok": not checks.failed,
        "passed": sum(1 for item in checks.items if item["ok"]),
        "total": len(checks.items),
        "checks": checks.items,
        "api": server_report,
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.markdown:
        args.markdown.parent.mkdir(parents=True, exist_ok=True)
        args.markdown.write_text(markdown_report(report), encoding="utf-8")

    for item in checks.items:
        print("[{}] {} - {}".format("PASS" if item["ok"] else "FAIL", item["name"], item["detail"]))
    print("RESULT: {} ({}/{} checks passed)".format("PASS" if report["ok"] else "FAIL", report["passed"], report["total"]))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
