from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Tuple


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = REPO_ROOT / "AI能力验证报告.json"


class VerificationFailure(RuntimeError):
    pass


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().upper()


def request_json(
    base_url: str,
    path: str,
    username: str = "",
    password: str = "",
    timeout: float = 120.0,
) -> Tuple[int, Dict[str, Any]]:
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
        "Connection": "close",
    }
    if username or password:
        token = base64.b64encode("{}:{}".format(username, password).encode("utf-8")).decode("ascii")
        headers["Authorization"] = "Basic {}".format(token)
    request = urllib.request.Request(
        base_url.rstrip("/") + path,
        data=b"{}",
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            status = response.status
            raw = response.read()
    except urllib.error.HTTPError as error:
        status = error.code
        raw = error.read()
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise VerificationFailure("响应不是有效 UTF-8 JSON：{}".format(error))
    if not isinstance(payload, dict):
        raise VerificationFailure("响应根节点不是 JSON 对象")
    return status, payload


def verify_evidence(
    base_url: str,
    username: str,
    password: str,
    output: Path,
) -> Dict[str, Any]:
    status, envelope = request_json(base_url, "/api/ai/self-test", username, password)
    if status != 200:
        raise VerificationFailure("自检接口返回 HTTP {}：{}".format(status, envelope.get("error", "")))
    if envelope.get("ok") is not True:
        raise VerificationFailure("自检接口未返回 ok=true")
    evidence = envelope.get("data")
    if not isinstance(evidence, dict):
        raise VerificationFailure("自检接口缺少 data 对象")
    if evidence.get("status") != "verified" or evidence.get("verified") is not True:
        reason = evidence.get("error") or "模型未配置或调用失败"
        raise VerificationFailure("真实 AI 能力未验证：{}".format(reason))

    for field in ("request_id", "provider", "model", "prompt", "response", "latency_ms"):
        if not evidence.get(field):
            raise VerificationFailure("自检记录缺少字段：{}".format(field))
    prompt = str(evidence["prompt"])
    response = str(evidence["response"])
    if not response.startswith("AI可辅助"):
        raise VerificationFailure("模型响应未满足固定提示词要求的开头")
    expected_prompt_hash = sha256_text(prompt)
    expected_response_hash = sha256_text(response)
    if evidence.get("prompt_sha256") != expected_prompt_hash:
        raise VerificationFailure("提示词 SHA256 不匹配")
    if evidence.get("response_sha256") != expected_response_hash:
        raise VerificationFailure("响应 SHA256 不匹配")

    evidence["verification"] = {
        "entry": "POST /api/ai/self-test",
        "method": "固定提示词调用已配置模型，并由服务端返回原始响应及SHA256",
        "reproduce_command": "python .\\03_构建与验证工具\\verify_ai_capability.py --base-url {}".format(
            base_url.rstrip("/")
        ),
        "verified_at": datetime.now(timezone.utc).isoformat(),
        "verifier": "verify_ai_capability.py",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return evidence


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="复验平台真实 AI 能力并保存机器可读证据")
    parser.add_argument(
        "--base-url",
        default=os.environ.get("HERITAGE_BASE_URL", "http://127.0.0.1:8080"),
        help="服务端根地址",
    )
    parser.add_argument("--username", default=os.environ.get("HERITAGE_BASIC_USER", ""))
    parser.add_argument("--password", default=os.environ.get("HERITAGE_BASIC_PASSWORD", ""))
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--timeout", type=float, default=120.0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        status, envelope = request_json(
            args.base_url,
            "/api/ai/self-test",
            args.username,
            args.password,
            args.timeout,
        )
        if status != 200 or envelope.get("ok") is not True:
            raise VerificationFailure("自检接口调用失败：HTTP {}".format(status))
        evidence = envelope.get("data") or {}
        if evidence.get("status") != "verified" or evidence.get("verified") is not True:
            raise VerificationFailure(
                "真实 AI 能力未验证：{}".format(evidence.get("error") or "模型未配置或调用失败")
            )
        prompt = str(evidence.get("prompt") or "")
        response = str(evidence.get("response") or "")
        if not prompt or not response.startswith("AI可辅助"):
            raise VerificationFailure("模型响应不满足固定提示词要求")
        if evidence.get("prompt_sha256") != sha256_text(prompt):
            raise VerificationFailure("提示词 SHA256 不匹配")
        if evidence.get("response_sha256") != sha256_text(response):
            raise VerificationFailure("响应 SHA256 不匹配")
        evidence["verification"] = {
            "entry": "POST /api/ai/self-test",
            "method": "固定提示词调用已配置模型，并由服务端返回原始响应及SHA256",
            "reproduce_command": "python .\\03_构建与验证工具\\verify_ai_capability.py --base-url {}".format(
                args.base_url.rstrip("/")
            ),
            "verified_at": datetime.now(timezone.utc).isoformat(),
            "verifier": "verify_ai_capability.py",
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("PASS: {} / {} / {} ms".format(evidence.get("provider"), evidence.get("model"), evidence.get("latency_ms")))
        print("证据已写入：{}".format(args.output))
        return 0
    except Exception as error:
        print("FAIL: {}".format(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
