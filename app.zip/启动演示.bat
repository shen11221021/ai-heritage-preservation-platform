﻿@echo off
chcp 65001 >nul
start "" "%~dp001_平台前端\index.html"
