from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import posixpath
import re
import sqlite3
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from functools import partial
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import parse_qs, unquote, urlparse

from agent_pipeline import (
    AGENT_BLUEPRINT,
    attach_platform_evidence,
    PIPELINE_VERSION,
    audit_generated_content,
    build_generation_prompt,
    build_stage,
    build_template_draft,
    digest_json,
    inspect_input,
    manifest as agent_pipeline_manifest,
    rank_knowledge,
)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().upper()


def new_request_id() -> str:
    return hashlib.sha256(os.urandom(16)).hexdigest()[:20].upper()


def load_showcase_cases() -> Dict[str, Any]:
    payload = json.loads(SHOWCASE_RECORD_PATH.read_text(encoding="utf-8"))
    cases = payload.get("cases") if isinstance(payload, dict) else None
    if not isinstance(cases, list) or len(cases) != 6:
        raise ValueError("案例矩阵登记表必须包含 6 条案例")
    return payload


def showcase_case_material(case: Dict[str, Any]) -> str:
    review = case.get("review") or {}
    return "\n".join(
        [
            str(case.get("id", "")),
            str(case.get("title", "")),
            str(case.get("site_key", "")),
            str(case.get("input", "")),
            " | ".join(str(item) for item in case.get("ai_steps", [])),
            str(case.get("output", "")),
            str(review.get("record_id", "")),
            str(review.get("reviewer", "")),
            str(review.get("decision", "")),
            str(review.get("detail", "")),
            " | ".join(str(item) for item in case.get("evidence_refs", [])),
        ]
    )


def verify_showcase_case(case_id: str) -> Dict[str, Any]:
    payload = load_showcase_cases()
    case = next((item for item in payload["cases"] if item.get("id") == case_id), None)
    if not case:
        raise ValueError("未知案例编号")
    expected = str(case.get("integrity_sha256", "")).upper()
    recomputed = sha256_text(showcase_case_material(case))
    return {
        "case_id": case_id,
        "verified": bool(expected and hmac.compare_digest(expected, recomputed)),
        "verification_source": "服务端按输入、AI 环节、输出和人工复核字段重算",
        "expected_sha256": expected,
        "recomputed_sha256": recomputed,
        "recorded_at": payload.get("generated_at", ""),
        "disclosure": "核验只证明案例字段未被改动，不把概念模型或模板输出等同于真实测绘、史料结论。",
    }


VERSION = "V2.0"
BASE_DIR = Path(__file__).resolve().parents[1]
SHOWCASE_RECORD_PATH = BASE_DIR / "01_平台前端" / "assets" / "showcase-cases.json"
SERVER_DIR = Path(__file__).resolve().parent
DATA_DIR = SERVER_DIR / "data"
DEFAULT_DB_PATH = DATA_DIR / "heritage.db"
SITE_DATA: Dict[str, Dict[str, Any]] = {
    "lie-shishan": {
        "name": "烈石山工事遗址",
        "type": "工事遗址",
        "focus": "战壕走向、构筑边界、地形高差和遗存完整性",
        "model_mode": "概念演示模型",
        "data_disclaimer": "依据影像资料进行解释性建模，非摄影测量成果，不可用于测绘量测。",
        "glb_size": "1,637,664 字节",
        "triangles": 13618,
        "position_count": 40854,
    },
    "qingxiang-wall": {
        "name": "勍香镇红色标语墙遗址",
        "type": "标语墙遗存",
        "focus": "墙面纹理、文字边缘、结构裂隙和周边环境",
        "model_mode": "概念演示模型",
        "data_disclaimer": "现场位置与尺度尚未确认，模型不是实测复原，不可用于测绘量测。",
        "glb_size": "2,615,324 字节",
        "triangles": 36266,
        "position_count": 108798,
    },
    "langyu-caomaoshan": {
        "name": "狼峪草帽山遗址",
        "type": "山地遗址",
        "focus": "大范围地形、植被遮挡、路径关系和重点遗存边界",
        "model_mode": "概念演示模型",
        "data_disclaimer": "工事位置、主体尺度与地形为展示假设，未完成现场测绘，不可用于量测。",
        "glb_size": "17,004,772 字节",
        "triangles": 127438,
        "position_count": 382314,
    },
}
KNOWLEDGE_BASE: List[Dict[str, Any]] = [
    {
        "id": "KB-01",
        "title": "遗址基础档案",
        "text": "基础档案建议记录遗址名称、级别、年代、位置、权属、保护范围、保存现状、历史沿革、采集人员和审核记录，并为每条资料保留来源。",
    },
    {
        "id": "KB-02",
        "title": "现场影像采集",
        "text": "照片采集应覆盖整体环境、主体结构、病害细部和比例尺信息；相邻照片保持较高重叠度，避免逆光、失焦和运动模糊。",
    },
    {
        "id": "KB-03",
        "title": "三维重建质量控制",
        "text": "重建前检查照片清晰度、重叠度和覆盖完整性；重建后检查模型孔洞、纹理错位、尺度异常和低置信区域，并保留处理日志。",
    },
    {
        "id": "KB-04",
        "title": "红色故事编写规则",
        "text": "红色故事应依据权威史料编写，人物、时间、地点和事件必须可核验。生成式内容只能作为初稿，不得替代专家审核和属地确认。",
    },
    {
        "id": "KB-05",
        "title": "模型格式与发布",
        "text": "浏览器展示优先使用 GLB/GLTF 格式，系统记录模型体积、三角面数、材质数量和加载耗时；发布前需完成移动端触控与兼容性测试。",
    },
    {
        "id": "KB-06",
        "title": "图文资料版权",
        "text": "照片、扫描件、地图、手稿和口述材料应记录作者或提供者、授权范围、使用期限和数字化时间。未授权材料不得公开发布。",
    },
    {
        "id": "KB-07",
        "title": "二维码展示页",
        "text": "二维码页面应包含遗址名称、模型浏览入口、讲解文本、资料来源、审核日期和纠错反馈入口，并支持移动端访问。",
    },
    {
        "id": "KB-08",
        "title": "异常处理与重试",
        "text": "图片上传、模型转换和内容生成任务应设置超时、失败原因、重试次数与人工接管状态，避免任务无声中断。",
    },
]
REVIEW_DECISIONS = {
    "pending": "待审核",
    "approved": "审核通过",
    "changes_requested": "退回修改",
    "rejected": "审核不通过",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_dotenv() -> None:
    candidates = [SERVER_DIR / ".env", BASE_DIR / ".env"]
    for path in candidates:
        if not path.is_file():
            continue
        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


load_dotenv()


def get_db_path() -> Path:
    configured = os.environ.get("HERITAGE_DB_PATH", "").strip()
    if not configured:
        return DEFAULT_DB_PATH
    path = Path(configured).expanduser()
    if not path.is_absolute():
        path = SERVER_DIR / path
    return path.resolve()


def db_connection() -> sqlite3.Connection:
    path = get_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(path), timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = WAL")
    return connection


def initialize_database() -> None:
    with db_connection() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS sites (
                site_key TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                focus TEXT NOT NULL,
                model_mode TEXT NOT NULL,
                data_disclaimer TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS archives (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                site_key TEXT NOT NULL,
                title TEXT NOT NULL,
                summary TEXT NOT NULL,
                source TEXT NOT NULL,
                review_status TEXT NOT NULL DEFAULT 'pending',
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(site_key) REFERENCES sites(site_key)
            );

            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                archive_id INTEGER NOT NULL,
                decision TEXT NOT NULL,
                reviewer TEXT NOT NULL,
                comment TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(archive_id) REFERENCES archives(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_archives_site ON archives(site_key);
            CREATE INDEX IF NOT EXISTS idx_reviews_archive ON reviews(archive_id);

            CREATE TABLE IF NOT EXISTS agent_runs (
                run_id TEXT PRIMARY KEY,
                site_key TEXT NOT NULL,
                goal TEXT NOT NULL,
                query TEXT NOT NULL,
                generation_mode TEXT NOT NULL,
                status TEXT NOT NULL,
                provider TEXT NOT NULL,
                model TEXT NOT NULL,
                latency_ms REAL NOT NULL,
                audit_score INTEGER NOT NULL,
                citation_count INTEGER NOT NULL,
                bundle_sha256 TEXT NOT NULL,
                result_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(site_key) REFERENCES sites(site_key)
            );

            CREATE INDEX IF NOT EXISTS idx_agent_runs_created ON agent_runs(created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_agent_runs_site ON agent_runs(site_key);
            """
        )
        now = utc_now()
        for key, site in SITE_DATA.items():
            connection.execute(
                """
                INSERT INTO sites(site_key, name, type, focus, model_mode, data_disclaimer, updated_at)
                VALUES(?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(site_key) DO UPDATE SET
                    name=excluded.name,
                    type=excluded.type,
                    focus=excluded.focus,
                    model_mode=excluded.model_mode,
                    data_disclaimer=excluded.data_disclaimer,
                    updated_at=excluded.updated_at
                """,
                (
                    key,
                    site["name"],
                    site["type"],
                    site["focus"],
                    site["model_mode"],
                    site["data_disclaimer"],
                    now,
                ),
            )
        seed_demo_archives(connection)


def seed_demo_archives(connection: sqlite3.Connection) -> None:
    if int(connection.execute("SELECT COUNT(*) FROM archives").fetchone()[0]) > 0:
        return
    now = utc_now()
    samples = [
        {
            "site_key": "lie-shishan",
            "title": "【演示样例】烈石山现场影像复核记录",
            "summary": "记录整体环境、结构边界和补采照片的来源，用于演示新建档案与审核留痕；不作为历史事实或测绘结论。",
            "source": "参赛演示样例，非真实史料结论",
            "created_by": "演示采集员",
            "review_status": "approved",
            "reviewer": "演示审核人",
            "comment": "来源已登记，同意作为界面审核流程演示。",
        },
        {
            "site_key": "qingxiang-wall",
            "title": "【演示样例】标语墙病害补充记录",
            "summary": "记录墙面病害观察和待核验事项，用于演示退回修改与状态留痕；现场位置、尺度和史实尚待确认。",
            "source": "参赛演示样例，非真实史料结论",
            "created_by": "演示采集员",
            "review_status": "changes_requested",
            "reviewer": "演示审核人",
            "comment": "请补充现场来源、拍摄时间和病害位置，再提交复核。",
        },
        {
            "site_key": "langyu-caomaoshan",
            "title": "【演示样例】狼峪草帽山采集计划复核记录",
            "summary": "登记概念模型、采集点位、模型质检和人工接管事项，用于演示 AIGC/智能体业务案例的复核留痕。",
            "source": "参赛演示样例，非真实测绘或史料结论",
            "created_by": "演示采集员",
            "review_status": "approved",
            "reviewer": "演示审核人",
            "comment": "概念模型和采集计划已登记，同意作为界面与流程演示。",
        },
    ]
    for sample in samples:
        cursor = connection.execute(
            """
            INSERT INTO archives(site_key, title, summary, source, review_status, created_by, created_at, updated_at)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                sample["site_key"],
                sample["title"],
                sample["summary"],
                sample["source"],
                sample["review_status"],
                sample["created_by"],
                now,
                now,
            ),
        )
        connection.execute(
            """
            INSERT INTO reviews(archive_id, decision, reviewer, comment, created_at)
            VALUES(?, ?, ?, ?, ?)
            """,
            (
                int(cursor.lastrowid),
                sample["review_status"],
                sample["reviewer"],
                sample["comment"],
                now,
            ),
        )



def row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    return {key: row[key] for key in row.keys()}


def search_knowledge(query: str) -> List[Dict[str, Any]]:
    return rank_knowledge(query, KNOWLEDGE_BASE, limit=4)


def legacy_search_knowledge(query: str) -> List[Dict[str, Any]]:
    normalized = query.strip().lower()
    if not normalized:
        return KNOWLEDGE_BASE[:3]
    terms = [term for term in re.split(r"[\s，。；、！？,.;!?]+", normalized) if term]
    expanded_terms: List[str] = []
    for term in terms:
        expanded_terms.append(term)
        if len(term) >= 4:
            expanded_terms.extend(term[index : index + 2] for index in range(len(term) - 1))
    terms = list(dict.fromkeys(expanded_terms))
    ranked: List[Tuple[int, Dict[str, Any]]] = []
    for entry in KNOWLEDGE_BASE:
        haystack = "{} {}".format(entry["title"], entry["text"]).lower()
        score = 30 if normalized in haystack else 0
        for term in terms:
            if term in entry["text"].lower():
                score += 2
            if term in entry["title"].lower():
                score += 6
        ranked.append((score, entry))
    ranked.sort(key=lambda item: item[0], reverse=True)
    selected = [entry for score, entry in ranked if score > 0][:4]
    return selected or KNOWLEDGE_BASE[:3]


def build_plan(site_key: str, goal: str, weather_check: bool, privacy_check: bool) -> Dict[str, Any]:
    site = SITE_DATA.get(site_key)
    if not site:
        raise ValueError("未知遗址案例")
    weather_rule = (
        "结合天气、日照和地形条件选定采集窗口"
        if weather_check
        else "按现场负责人确定的窗口执行采集"
    )
    privacy_rule = (
        "对人物、车辆、门牌和敏感位置执行脱敏复核"
        if privacy_check
        else "按普通档案流程进行内容复核"
    )
    steps = [
        {
            "role": "采集策划智能体",
            "detail": "{}；围绕{}生成点位、角度、重叠度和备份要求。".format(weather_rule, site["focus"]),
        },
        {
            "role": "多模态质量评估",
            "detail": "在浏览器侧预检分辨率、曝光、对比度和清晰度，标记不合格照片并给出补采建议。",
        },
        {
            "role": "三维重建工单",
            "detail": "将合格影像登记为重建任务，记录算法、参数、耗时、模型体积、三角面数和异常日志。当前案例模型为概念演示模型。",
        },
        {
            "role": "知识检索",
            "detail": "从已审核档案条目中检索遗址记录、采集规范、版权约束和历史资料索引。",
        },
        {
            "role": "AIGC讲解生成",
            "detail": "生成讲解与摘要初稿，附资料来源；人物、时间、地点必须人工核验。",
        },
        {
            "role": "人工审核关卡",
            "detail": "{}；历史内容由史料专家、属地管理人员和项目负责人依次确认。".format(privacy_rule),
        },
        {
            "role": "成果发布与追踪",
            "detail": "生成模型页面、访问二维码和版本编号，记录发布时间、审核人、反馈和修订历史。",
        },
    ]
    return {
        "site_key": site_key,
        "summary": "{}任务已拆分。目标：{}".format(site["name"], goal or "完成遗址采集建档与成果审核"),
        "mode": "rules",
        "steps": steps,
        "generated_at": utc_now(),
    }


def offline_story(site_key: str, entries: Iterable[Dict[str, Any]]) -> str:
    return build_template_draft(SITE_DATA[site_key], list(entries))
    site = SITE_DATA[site_key]
    source_titles = "、".join(entry["title"] for entry in entries)
    return (
        "【待审核初稿】{}数字化讲解\n\n"
        "{}属于{}。本稿采用“先客观记录、后史料解释”的方式编写，当前重点记录{}，"
        "并保存采集影像、三维模型、处理参数和审核日志。\n\n"
        "展示层面使用浏览器三维场景呈现空间关系，并提供 PNG 截图和 GLB 导出。"
        "当前案例三维模型为{}，{}本段为离线模板初稿，不补写未经核实的人物、时间或事件。\n\n"
        "参考资料：{}。\n\n"
        "发布前必须补充权威史料来源，并由属地管理单位、史料专家和项目负责人完成人工审核。"
    ).format(
        site["name"],
        site["name"],
        site["type"],
        site["focus"],
        site["model_mode"],
        site["data_disclaimer"],
        source_titles,
    )


def ai_capability_status() -> Dict[str, Any]:
    settings = model_settings()
    configured = bool(settings["endpoint"] and settings["model"])
    return {
        "generation_mode": "online_model" if configured else "offline_template",
        "model_configured": configured,
        "provider": settings["provider"] if configured else "",
        "model": settings["model"] if configured else "",
        "self_test_endpoint": "/api/ai/self-test",
        "agent_run_endpoint": "/api/agent/run",
        "agent_metrics_endpoint": "/api/agent/metrics",
        "agent_count": len(AGENT_BLUEPRINT),
        "pipeline_version": PIPELINE_VERSION,
        "planning_scope": "multi_agent_pipeline",
        "retrieval_scope": "citation_bound_keyword_rag",
        "disclosure": (
            "已配置大语言模型，可执行在线生成任务；输出仍须人工审核。"
            if configured
            else "未配置大语言模型；当前提供规则智能体规划、关键词检索和明确标注的离线模板初稿，不冒充真实大模型生成。"
        ),
    }


def model_settings() -> Dict[str, str]:
    endpoint = os.environ.get("HERITAGE_LLM_ENDPOINT", "").strip()
    model = os.environ.get("HERITAGE_LLM_MODEL", "").strip()
    provider = os.environ.get("HERITAGE_LLM_PROVIDER", "").strip().lower()
    if not provider:
        provider = "ollama" if endpoint and "/v1" not in endpoint else "openai"
    return {
        "provider": provider,
        "endpoint": endpoint,
        "model": model,
        "api_key": os.environ.get("HERITAGE_LLM_API_KEY", "").strip(),
    }


def call_configured_model(prompt: str) -> str:
    settings = model_settings()
    endpoint = settings["endpoint"]
    model = settings["model"]
    if not endpoint or not model:
        raise RuntimeError("服务端未配置大模型")

    timeout = int(os.environ.get("HERITAGE_LLM_TIMEOUT", "60"))
    max_tokens = int(os.environ.get("HERITAGE_LLM_MAX_TOKENS", "700"))
    system_prompt = (
        "你是红色遗址数字化保护平台的内容助手。只根据用户提供的资料生成初稿，"
        "不得编造人物、时间、地点和事件，并明确标记待审核项。"
    )

    if settings["provider"] == "ollama":
        url = "{}/api/chat".format(endpoint.rstrip("/"))
        payload = {
            "model": model,
            "stream": False,
            "options": {"temperature": 0.1, "num_predict": max_tokens},
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
        }
    else:
        base = endpoint.rstrip("/")
        url = base if base.endswith("/chat/completions") else "{}/v1/chat/completions".format(base)
        payload = {
            "model": model,
            "temperature": 0.1,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
        }

    headers = {"Content-Type": "application/json"}
    if settings["api_key"]:
        headers["Authorization"] = "Bearer {}".format(settings["api_key"])
    request = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        raise RuntimeError("模型服务返回 {}：{}".format(error.code, detail[:240]))
    except urllib.error.URLError as error:
        raise RuntimeError("无法连接模型服务：{}".format(error.reason))

    if settings["provider"] == "ollama":
        return str((body.get("message") or {}).get("content") or body.get("response") or "").strip()
    choices = body.get("choices") or []
    if not choices:
        return ""
    return str((choices[0].get("message") or {}).get("content") or "").strip()


def run_ai_self_test() -> Dict[str, Any]:
    settings = model_settings()
    configured = bool(settings["endpoint"] and settings["model"])
    evidence: Dict[str, Any] = {
        "service": "HeritagePlatformAISelfTest",
        "schema_version": "1.0",
        "request_id": new_request_id(),
        "status": "not_configured" if not configured else "running",
        "verified": False,
        "provider": settings["provider"] if configured else "",
        "model": settings["model"] if configured else "",
        "generated_at": utc_now(),
    }
    if not configured:
        evidence["error"] = "未配置真实大模型，当前只能使用离线规则与模板"
        evidence["disclosure"] = ai_capability_status()["disclosure"]
        return evidence

    prompt = (
        "这是大模型能力自检。请只输出一句中文，必须以“AI可辅助”开头，"
        "说明AI能够为基层红色遗址保护提供什么帮助；不得虚构遗址史实。"
    )
    evidence["prompt"] = prompt
    evidence["prompt_sha256"] = sha256_text(prompt)
    started = time.perf_counter()
    try:
        response_text = call_configured_model(prompt)
        evidence["latency_ms"] = round((time.perf_counter() - started) * 1000, 2)
        if not response_text:
            raise RuntimeError("模型服务返回空内容")
        evidence.update(
            {
                "status": "verified",
                "verified": True,
                "response": response_text,
                "response_sha256": sha256_text(response_text),
                "disclosure": "本证据来自服务端真实模型在线推理；输出只作能力验证，不构成史料结论。",
            }
        )
    except Exception as error:
        evidence["latency_ms"] = round((time.perf_counter() - started) * 1000, 2)
        evidence["status"] = "failed"
        evidence["error"] = str(error)
        evidence["disclosure"] = "真实模型调用失败，本次没有形成可用AI生成证据。"
    return evidence


def persist_agent_run(result: Dict[str, Any]) -> None:
    with db_connection() as connection:
        connection.execute(
            """
            INSERT OR REPLACE INTO agent_runs(
                run_id, site_key, goal, query, generation_mode, status, provider, model,
                latency_ms, audit_score, citation_count, bundle_sha256, result_json, created_at
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                result["run_id"],
                result["site_key"],
                result["goal"],
                result["query"],
                result["generation"]["mode"],
                result["status"],
                result["generation"].get("provider", ""),
                result["generation"].get("model", ""),
                float(result["latency_ms"]),
                int(result["audit"]["score"]),
                len(result["audit"].get("valid_citations", [])),
                result["bundle_sha256"],
                json.dumps(result, ensure_ascii=False, separators=(",", ":")),
                result["generated_at"],
            ),
        )


def list_agent_runs(limit: int = 20, site_key: str = "") -> List[Dict[str, Any]]:
    safe_limit = max(1, min(int(limit), 100))
    with db_connection() as connection:
        if site_key:
            rows = connection.execute(
                "SELECT result_json FROM agent_runs WHERE site_key=? ORDER BY created_at DESC LIMIT ?",
                (site_key, safe_limit),
            ).fetchall()
        else:
            rows = connection.execute(
                "SELECT result_json FROM agent_runs ORDER BY created_at DESC LIMIT ?",
                (safe_limit,),
            ).fetchall()
    result: List[Dict[str, Any]] = []
    for row in rows:
        try:
            result.append(json.loads(row["result_json"]))
        except json.JSONDecodeError:
            continue
    return result


def agent_metrics() -> Dict[str, Any]:
    with db_connection() as connection:
        row = connection.execute(
            """
            SELECT
                COUNT(*) AS total_runs,
                SUM(CASE WHEN generation_mode='online_model' THEN 1 ELSE 0 END) AS online_runs,
                AVG(latency_ms) AS average_latency_ms,
                AVG(audit_score) AS average_audit_score,
                AVG(citation_count) AS average_citation_count
            FROM agent_runs
            """
        ).fetchone()
    total = int(row["total_runs"] or 0)
    online = int(row["online_runs"] or 0)
    return {
        "total_runs": total,
        "online_model_runs": online,
        "offline_template_runs": total - online,
        "online_evidence_rate": round(online * 100 / total, 2) if total else 0.0,
        "average_latency_ms": round(float(row["average_latency_ms"] or 0), 2),
        "average_audit_score": round(float(row["average_audit_score"] or 0), 2),
        "average_citation_count": round(float(row["average_citation_count"] or 0), 2),
        "pipeline_version": PIPELINE_VERSION,
    }


def run_agent_pipeline(payload: Dict[str, Any]) -> Dict[str, Any]:
    site_key = str(payload.get("site_key", "")).strip()
    site = SITE_DATA.get(site_key)
    if not site:
        raise ValueError("未知遗址案例")
    goal = str(payload.get("goal", "")).strip() or "完成现场采集、模型复核、讲解审核和成果发布"
    query = str(payload.get("query", "")).strip() or "{} {} 数字化保护".format(site["type"], site["focus"])
    guard = inspect_input(goal, query)
    if not guard["passed"]:
        if not guard["length_ok"]:
            raise ValueError("任务目标或检索内容超过允许长度")
        raise ValueError("检测到试图绕过审核、泄露提示词或改变系统边界的指令")

    run_id = new_request_id()
    pipeline_started = time.perf_counter()
    generated_at = utc_now()
    stages: List[Dict[str, Any]] = []
    agents = {agent["id"]: agent for agent in AGENT_BLUEPRINT}

    started = time.perf_counter()
    stages.append(build_stage(
        agents["intake_guard"],
        "completed",
        guard,
        generated_at,
        round((time.perf_counter() - started) * 1000, 2),
    ))

    started = time.perf_counter()
    entries = search_knowledge(query)
    retrieval_artifact = {
        "query": query,
        "retrieval_mode": "keyword_citation_binding",
        "entries": entries,
    }
    stages.append(build_stage(
        agents["retrieval_agent"],
        "completed",
        retrieval_artifact,
        generated_at,
        round((time.perf_counter() - started) * 1000, 2),
        {"citation_count": len(entries)},
    ))

    started = time.perf_counter()
    plan = build_plan(
        site_key,
        goal,
        bool(payload.get("weather_check", True)),
        bool(payload.get("privacy_check", True)),
    )
    stages.append(build_stage(
        agents["planner_agent"],
        "completed",
        plan,
        generated_at,
        round((time.perf_counter() - started) * 1000, 2),
        {"step_count": len(plan["steps"])},
    ))

    prompt = build_generation_prompt(site, goal, entries)
    generation_request_id = new_request_id()
    generation_started = time.perf_counter()
    fallback_reason = ""
    try:
        model_response = call_configured_model(prompt)
        if not model_response:
            raise RuntimeError("模型服务返回空内容")
        generation_mode = "online_model"
    except Exception as error:
        fallback_reason = str(error)
        model_response = build_template_draft(site, entries, fallback_reason)
        generation_mode = "offline_template"
    generation_latency_ms = round((time.perf_counter() - generation_started) * 1000, 2)
    settings = model_settings()
    candidate_content = (
        attach_platform_evidence(model_response, site, entries, generation_mode)
        if generation_mode == "online_model"
        else model_response
    )
    initial_audit = audit_generated_content(candidate_content, entries, generation_mode)
    correction_applied = initial_audit["status"] != "pass"
    final_content = build_template_draft(site, entries, fallback_reason) if correction_applied else candidate_content
    final_audit = audit_generated_content(final_content, entries, generation_mode)
    generation = {
        "mode": generation_mode,
        "provider": settings["provider"] if generation_mode == "online_model" else "offline",
        "model": settings["model"] if generation_mode == "online_model" else "template_v2",
        "request_id": generation_request_id,
        "prompt_sha256": sha256_text(prompt),
        "response": model_response,
        "response_sha256": sha256_text(model_response),
        "candidate_content": candidate_content,
        "candidate_sha256": sha256_text(candidate_content),
        "final_content": final_content,
        "final_sha256": sha256_text(final_content),
        "latency_ms": generation_latency_ms,
        "fallback_reason": fallback_reason,
        "disclosure": (
            "模型原始输出已保留为证据；平台附注、审计和纠错过程可追溯，最终内容仍须人工审核。"
            if generation_mode == "online_model"
            else "本次为离线模板降级结果，不能作为真实模型输出证据。"
        ),
    }
    stages.append(build_stage(
        agents["generation_agent"],
        "completed" if generation_mode == "online_model" else "fallback",
        generation,
        generated_at,
        generation_latency_ms,
        {
            "request_id": generation_request_id,
            "response_sha256": generation["response_sha256"],
            "final_sha256": generation["final_sha256"],
            "mode": generation_mode,
        },
    ))

    started = time.perf_counter()
    stages.append(build_stage(
        agents["audit_agent"],
        initial_audit["status"],
        initial_audit,
        generated_at,
        round((time.perf_counter() - started) * 1000, 2),
        {"audit_score": initial_audit["score"], "valid_citations": initial_audit["valid_citations"]},
    ))

    correction_artifact = {
        "applied": correction_applied,
        "reason": "初稿未通过证据审计，已切换为引用完整、边界明确的安全初稿。"
        if correction_applied
        else "初稿通过证据审计，无需纠错重写。",
        "final_audit": final_audit,
        "final_sha256": generation["final_sha256"],
        "final_content": final_content,
    }
    stages.append(build_stage(
        agents["correction_agent"],
        "completed",
        correction_artifact,
        generated_at,
        0.0,
        {"correction_applied": correction_applied, "final_audit_score": final_audit["score"]},
    ))

    human_gate = {
        "status": "pending_human_review",
        "required_roles": ["史料专家", "属地管理单位", "项目负责人"],
        "release_blocked": True,
        "reason": "AI审计通过不等于事实审核通过，发布前必须完成人工签批。",
    }
    stages.append(build_stage(
        agents["human_review_gate"],
        "pending",
        human_gate,
        generated_at,
        0.0,
    ))

    total_latency_ms = round((time.perf_counter() - pipeline_started) * 1000, 2)
    status = "pending_human_review" if final_audit["status"] == "pass" else "revision_required"
    hash_core = {
        "run_id": run_id,
        "site_key": site_key,
        "goal": goal,
        "query": query,
        "generation": generation,
        "initial_audit": initial_audit,
        "correction": correction_artifact,
        "audit": final_audit,
        "stages": stages,
        "generated_at": generated_at,
    }
    bundle_sha256 = digest_json(hash_core)
    result = {
        **hash_core,
        "pipeline_version": PIPELINE_VERSION,
        "pipeline": agent_pipeline_manifest(),
        "status": status,
        "latency_ms": total_latency_ms,
        "bundle_sha256": bundle_sha256,
        "evidence_notice": "本运行记录保留模型原始输出，并证明引用绑定、审计、纠错和人工复核状态；待人工审核状态不允许直接发布。",
    }
    persist_agent_run(result)
    return result


class HeritageRequestHandler(SimpleHTTPRequestHandler):
    server_version = "HeritagePlatform/{}".format(VERSION)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(BASE_DIR), **kwargs)

    def log_message(self, format_string: str, *args: Any) -> None:
        sys.stdout.write("[%s] %s\n" % (self.log_date_time_string(), format_string % args))
        sys.stdout.flush()

    def end_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header(
            "Permissions-Policy",
            "camera=(), microphone=(), geolocation=(), payment=()",
        )
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Allow", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self.send_response(HTTPStatus.FOUND)
            self.send_header("Location", "/01_平台前端/index.html")
            self.end_headers()
            return
        if parsed.path == "/api/health":
            self.send_json(
                {
                    "ok": True,
                    "status": "online",
                    "version": VERSION,
                    "server_time": utc_now(),
                }
            )
            return
        if not self.authorized():
            return
        if parsed.path.startswith("/api/"):
            self.handle_api_get(parsed.path, parse_qs(parsed.query))
            return
        if not self.public_static_path(parsed.path):
            self.send_json({"ok": False, "error": "资源不存在"}, HTTPStatus.NOT_FOUND)
            return
        super().do_GET()

    def do_HEAD(self) -> None:
        parsed = urlparse(self.path)
        if not self.authorized():
            return
        if not self.public_static_path(parsed.path):
            self.send_json({"ok": False, "error": "资源不存在"}, HTTPStatus.NOT_FOUND)
            return
        super().do_HEAD()

    @staticmethod
    def public_static_path(path: str) -> bool:
        decoded = path or "/"
        for _ in range(3):
            expanded = unquote(decoded)
            if expanded == decoded:
                break
            decoded = expanded
        if "\x00" in decoded or "\\" in decoded:
            return False
        normalized = posixpath.normpath(decoded)
        allowed_prefixes = (
            "/01_平台前端/",
            "/02_三维案例源码/",
        )
        if normalized != "/01_平台前端/index.html" and not normalized.startswith(allowed_prefixes):
            return False
        relative = normalized.lstrip("/")
        candidate = (BASE_DIR / Path(*relative.split("/"))).resolve()
        for allowed_root in (
            (BASE_DIR / "01_平台前端").resolve(),
            (BASE_DIR / "02_三维案例源码").resolve(),
        ):
            try:
                if os.path.commonpath((str(candidate), str(allowed_root))) == str(allowed_root):
                    return True
            except ValueError:
                continue
        return False

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if not self.authorized():
            return
        if not parsed.path.startswith("/api/"):
            self.send_json({"ok": False, "error": "接口不存在"}, HTTPStatus.NOT_FOUND)
            return
        self.handle_api_post(parsed.path)

    def authorized(self) -> bool:
        username = os.environ.get("HERITAGE_BASIC_USER", "").strip()
        password = os.environ.get("HERITAGE_BASIC_PASSWORD", "").strip()
        if not username:
            return True
        header = self.headers.get("Authorization", "")
        if not header.startswith("Basic "):
            self.request_auth()
            return False
        try:
            decoded = base64.b64decode(header[6:]).decode("utf-8")
            supplied_user, supplied_password = decoded.split(":", 1)
        except (ValueError, UnicodeDecodeError):
            self.request_auth()
            return False
        valid = hmac.compare_digest(supplied_user, username) and hmac.compare_digest(
            supplied_password, password
        )
        if not valid:
            self.request_auth()
        return valid

    def request_auth(self) -> None:
        self.send_response(HTTPStatus.UNAUTHORIZED)
        self.send_header("WWW-Authenticate", 'Basic realm="Heritage Platform"')
        self.send_header("Content-Type", "application/json; charset=utf-8")
        payload = json.dumps({"ok": False, "error": "需要演示账号和密码"}, ensure_ascii=False)
        self.end_headers()
        self.wfile.write(payload.encode("utf-8"))

    def send_json(self, payload: Dict[str, Any], status: int = HTTPStatus.OK) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> Dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("请求长度无效")
        if length <= 0 or length > 1048576:
            raise ValueError("请求体为空或超过 1 MB")
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("请求体不是有效 JSON")
        if not isinstance(payload, dict):
            raise ValueError("请求体必须是 JSON 对象")
        return payload

    def handle_api_get(self, path: str, query: Dict[str, List[str]]) -> None:
        try:
            if path == "/api/health":
                self.send_json({"ok": True, "data": self.system_status()})
                return
            if path == "/api/system/status":
                self.send_json({"ok": True, "data": self.system_status()})
                return
            if path == "/api/ai/status":
                self.send_json({"ok": True, "data": ai_capability_status()})
                return
            if path == "/api/agent/manifest":
                self.send_json({"ok": True, "data": agent_pipeline_manifest()})
                return
            if path == "/api/agent/metrics":
                self.send_json({"ok": True, "data": agent_metrics()})
                return
            if path == "/api/showcase/cases":
                self.send_json({"ok": True, "data": load_showcase_cases()})
                return
            if path == "/api/agent/runs":
                limit = int((query.get("limit") or ["20"])[0])
                site_key = (query.get("site_key") or [""])[0].strip()
                self.send_json({"ok": True, "data": list_agent_runs(limit, site_key)})
                return
            if path in ("/api/cases", "/api/sites"):
                self.send_json({"ok": True, "data": list(SITE_DATA.values())})
                return
            if path == "/api/archives":
                site_key = (query.get("site_key") or [""])[0].strip()
                self.send_json({"ok": True, "data": self.list_archives(site_key)})
                return
            match = re.fullmatch(r"/api/archives/(\d+)", path)
            if match:
                archive = self.get_archive(int(match.group(1)))
                if not archive:
                    self.send_json({"ok": False, "error": "档案不存在"}, HTTPStatus.NOT_FOUND)
                    return
                self.send_json({"ok": True, "data": archive})
                return
            if path == "/api/export/archives":
                self.send_json({"ok": True, "exported_at": utc_now(), "data": self.list_archives("")})
                return
            self.send_json({"ok": False, "error": "接口不存在"}, HTTPStatus.NOT_FOUND)
        except Exception as error:
            self.send_json({"ok": False, "error": str(error)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def handle_api_post(self, path: str) -> None:
        try:
            payload = self.read_json()
            if path == "/api/showcase/verify":
                case_id = str(payload.get("case_id", "")).strip().upper()
                self.send_json({"ok": True, "data": verify_showcase_case(case_id)})
                return
            if path == "/api/plan":
                site_key = str(payload.get("site_key", "")).strip()
                goal = str(payload.get("goal", "")).strip()
                weather = bool(payload.get("weather_check", True))
                privacy = bool(payload.get("privacy_check", True))
                self.send_json({"ok": True, "data": build_plan(site_key, goal, weather, privacy)})
                return
            if path == "/api/knowledge/search":
                query = str(payload.get("query", "")).strip()
                self.send_json(
                    {
                        "ok": True,
                        "data": {
                            "query": query,
                            "entries": search_knowledge(query),
                            "retrieval_mode": "keyword",
                            "generated_at": utc_now(),
                        },
                    }
                )
                return
            if path == "/api/agent/run":
                self.send_json({"ok": True, "data": run_agent_pipeline(payload)})
                return
            if path == "/api/ai/generate":
                self.handle_generate(payload)
                return
            if path == "/api/ai/self-test":
                self.send_json({"ok": True, "data": run_ai_self_test()})
                return
            if path == "/api/archives":
                self.handle_create_archive(payload)
                return
            match = re.fullmatch(r"/api/archives/(\d+)/reviews", path)
            if match:
                self.handle_review(int(match.group(1)), payload)
                return
            self.send_json({"ok": False, "error": "接口不存在"}, HTTPStatus.NOT_FOUND)
        except ValueError as error:
            self.send_json({"ok": False, "error": str(error)}, HTTPStatus.BAD_REQUEST)
        except Exception as error:
            self.send_json({"ok": False, "error": str(error)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def handle_generate(self, payload: Dict[str, Any]) -> None:
        site_key = str(payload.get("site_key", "")).strip()
        if site_key not in SITE_DATA:
            raise ValueError("未知遗址案例")
        query = str(payload.get("query", "")).strip() or SITE_DATA[site_key]["type"]
        prompt = str(payload.get("prompt", "")).strip()
        entries = search_knowledge(query)
        if not prompt:
            prompt = "\n".join(
                [
                    "遗址：{}".format(SITE_DATA[site_key]["name"]),
                    "类型：{}".format(SITE_DATA[site_key]["type"]),
                    "记录重点：{}".format(SITE_DATA[site_key]["focus"]),
                    "模型说明：{}；{}".format(
                        SITE_DATA[site_key]["model_mode"],
                        SITE_DATA[site_key]["data_disclaimer"],
                    ),
                    "参考资料：",
                    *["- {}：{}".format(entry["title"], entry["text"]) for entry in entries],
                    "请生成300至500字的讲解初稿。不得补写未经提供的史实，明确列出一至两条待审核信息。",
                ]
            )
        generation_request_id = new_request_id()
        started = time.perf_counter()
        try:
            generated = call_configured_model(prompt)
            if not generated:
                raise RuntimeError("模型服务返回空内容")
            generation_latency_ms = round((time.perf_counter() - started) * 1000, 2)
            self.send_json(
                {
                    "ok": True,
                    "data": {
                        "content": generated,
                        "mode": "online_model",
                        "model": model_settings()["model"],
                        "provider": model_settings()["provider"],
                        "request_id": generation_request_id,
                        "prompt_sha256": sha256_text(prompt),
                        "response_sha256": sha256_text(generated),
                        "latency_ms": generation_latency_ms,
                        "disclosure": ai_capability_status()["disclosure"],
                        "generated_at": utc_now(),
                    },
                }
            )
        except Exception as error:
            self.send_json(
                {
                    "ok": True,
                    "data": {
                        "content": offline_story(site_key, entries),
                        "mode": "offline_template",
                        "model": model_settings()["model"],
                        "provider": model_settings()["provider"],
                        "request_id": generation_request_id,
                        "prompt_sha256": sha256_text(prompt),
                        "latency_ms": round((time.perf_counter() - started) * 1000, 2),
                        "disclosure": ai_capability_status()["disclosure"],
                        "warning": str(error),
                        "fallback_reason": str(error),
                        "generated_at": utc_now(),
                    },
                }
            )

    def handle_create_archive(self, payload: Dict[str, Any]) -> None:
        site_key = str(payload.get("site_key", "")).strip()
        if site_key not in SITE_DATA:
            raise ValueError("请选择有效遗址")
        title = str(payload.get("title", "")).strip()
        summary = str(payload.get("summary", "")).strip()
        source = str(payload.get("source", "")).strip()
        created_by = str(payload.get("created_by", "")).strip()
        if not title or len(title) > 120:
            raise ValueError("档案标题必填且不超过 120 字")
        if not summary or len(summary) > 4000:
            raise ValueError("档案内容必填且不超过 4000 字")
        if not source or len(source) > 500:
            raise ValueError("资料来源必填且不超过 500 字")
        if not created_by or len(created_by) > 80:
            raise ValueError("创建人必填且不超过 80 字")
        now = utc_now()
        with db_connection() as connection:
            cursor = connection.execute(
                """
                INSERT INTO archives(site_key, title, summary, source, review_status, created_by, created_at, updated_at)
                VALUES(?, ?, ?, ?, 'pending', ?, ?, ?)
                """,
                (site_key, title, summary, source, created_by, now, now),
            )
            archive_id = int(cursor.lastrowid)
        self.send_json({"ok": True, "data": self.get_archive(archive_id)}, HTTPStatus.CREATED)

    def handle_review(self, archive_id: int, payload: Dict[str, Any]) -> None:
        archive = self.get_archive(archive_id)
        if not archive:
            raise ValueError("档案不存在")
        decision = str(payload.get("decision", "")).strip()
        reviewer = str(payload.get("reviewer", "")).strip()
        comment = str(payload.get("comment", "")).strip()
        if decision not in REVIEW_DECISIONS:
            raise ValueError("审核结论无效")
        if not reviewer or len(reviewer) > 80:
            raise ValueError("审核人必填且不超过 80 字")
        if len(comment) > 2000:
            raise ValueError("审核意见不超过 2000 字")
        now = utc_now()
        with db_connection() as connection:
            connection.execute(
                """
                INSERT INTO reviews(archive_id, decision, reviewer, comment, created_at)
                VALUES(?, ?, ?, ?, ?)
                """,
                (archive_id, decision, reviewer, comment, now),
            )
            connection.execute(
                "UPDATE archives SET review_status=?, updated_at=? WHERE id=?",
                (decision, now, archive_id),
            )
        self.send_json({"ok": True, "data": self.get_archive(archive_id)})

    def list_archives(self, site_key: str) -> List[Dict[str, Any]]:
        with db_connection() as connection:
            if site_key:
                rows = connection.execute(
                    "SELECT * FROM archives WHERE site_key=? ORDER BY id DESC",
                    (site_key,),
                ).fetchall()
            else:
                rows = connection.execute("SELECT * FROM archives ORDER BY id DESC").fetchall()
            result: List[Dict[str, Any]] = []
            for row in rows:
                item = row_to_dict(row)
                reviews = connection.execute(
                    "SELECT * FROM reviews WHERE archive_id=? ORDER BY id DESC",
                    (item["id"],),
                ).fetchall()
                item["site_name"] = SITE_DATA.get(item["site_key"], {}).get("name", item["site_key"])
                item["review_status_label"] = REVIEW_DECISIONS.get(
                    item["review_status"], item["review_status"]
                )
                item["reviews"] = [row_to_dict(review) for review in reviews]
                result.append(item)
            return result

    def get_archive(self, archive_id: int) -> Optional[Dict[str, Any]]:
        for item in self.list_archives(""):
            if item["id"] == archive_id:
                return item
        return None

    def system_status(self) -> Dict[str, Any]:
        with db_connection() as connection:
            archive_count = int(connection.execute("SELECT COUNT(*) FROM archives").fetchone()[0])
            review_count = int(connection.execute("SELECT COUNT(*) FROM reviews").fetchone()[0])
        ai = ai_capability_status()
        settings = model_settings()
        return {
            "service": "AI智能体驱动的基层红色遗址保护平台",
            "version": VERSION,
            "status": "online",
            "server_time": utc_now(),
            "database": {
                "ready": True,
                "storage": "SQLite",
                "archive_count": archive_count,
                "review_count": review_count,
                "agent_run_count": agent_metrics()["total_runs"],
            },
            "agent_pipeline": agent_metrics(),
            "model_service": {
                "configured": bool(settings["endpoint"] and settings["model"]),
                "generation_mode": ai["generation_mode"],
                "disclosure": ai["disclosure"],
                "provider": settings["provider"] if settings["endpoint"] else "",
                "model": settings["model"] if settings["endpoint"] else "",
                "self_test_endpoint": "/api/ai/self-test",
                "server_side_key": bool(settings["api_key"]),
            },
            "ai_capability": ai,
            "public_url": os.environ.get("HERITAGE_PUBLIC_URL", "").strip(),
            "auth_enabled": bool(os.environ.get("HERITAGE_BASIC_USER", "").strip()),
            "cases": list(SITE_DATA.values()),
            "showcase_matrix": {
                "case_count": len(load_showcase_cases()["cases"]),
                "site_cases": 3,
                "business_cases": 3,
                "verification_endpoint": "/api/showcase/verify",
            },
        }


def main() -> None:
    initialize_database()
    host = os.environ.get("HERITAGE_HOST", "0.0.0.0")
    port = int(os.environ.get("HERITAGE_PORT", os.environ.get("PORT", "8080")))
    handler = partial(HeritageRequestHandler)
    server = ThreadingHTTPServer((host, port), handler)
    public_url = os.environ.get("HERITAGE_PUBLIC_URL", "")
    print("AI智能体驱动的基层红色遗址保护平台 {}".format(VERSION))
    print("本地地址: http://127.0.0.1:{}".format(port))
    if public_url:
        print("公网地址: {}".format(public_url))
    print("数据库: {}".format(get_db_path()))
    print("按 Ctrl+C 停止服务。")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止。")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
