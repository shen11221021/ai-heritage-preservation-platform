from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Dict, Iterable, List, Sequence

PIPELINE_VERSION = "2.0"
CITATION_PATTERN = re.compile(r"\[(KB-\d{2})\]")
PROMPT_INJECTION_PATTERN = re.compile(
    r"(忽略(?:以上|前面|之前)|绕过(?:限制|审核)|泄露(?:系统|提示词|密钥)|"
    r"system\s*prompt|developer\s*message|jailbreak)",
    re.IGNORECASE,
)
DATE_PATTERN = re.compile(r"(?:18|19|20)\d{2}年(?:\d{1,2}月)?(?:\d{1,2}日)?")
PERSON_ROLE_PATTERN = re.compile(
    r"[\u4e00-\u9fff]{2,4}(?:烈士|同志|将军|队长|书记|主任|馆长|研究员)"
)
HISTORICAL_CLAIM_TERMS = (
    "红军", "长征", "抗战", "抗日战争", "解放战争", "战斗", "牺牲",
    "战役", "敌人", "部队", "行军", "革命根据地",
)

AGENT_BLUEPRINT: List[Dict[str, str]] = [
    {
        "id": "intake_guard",
        "name": "输入与风险守卫",
        "role": "Guard Agent",
        "capability": "输入长度、提示注入、敏感指令和任务边界检查",
        "output": "受控任务单",
    },
    {
        "id": "retrieval_agent",
        "name": "知识检索智能体",
        "role": "Retriever Agent",
        "capability": "知识条目召回、相关性排序、引用编号和来源绑定",
        "output": "带编号的检索证据包",
    },
    {
        "id": "planner_agent",
        "name": "采集规划智能体",
        "role": "Planner Agent",
        "capability": "按遗址类型生成采集、质检、建模、审核和发布步骤",
        "output": "结构化任务计划",
    },
    {
        "id": "generation_agent",
        "name": "AIGC讲解智能体",
        "role": "Writer Agent",
        "capability": "受控检索增强生成，未配置模型时明确降级为模板",
        "output": "带引用和待审核标记的初稿",
    },
    {
        "id": "audit_agent",
        "name": "证据审计智能体",
        "role": "Auditor Agent",
        "capability": "引用覆盖、事实风险、免责声明、长度和提示注入复核",
        "output": "质量门禁与风险标记",
    },
    {
        "id": "correction_agent",
        "name": "纠错重写智能体",
        "role": "Repair Agent",
        "capability": "拦截无依据历史表述，生成引用完整的安全初稿并二次审计",
        "output": "纠错后安全初稿",
    },
    {
        "id": "human_review_gate",
        "name": "人工复核关卡",
        "role": "Human-in-the-loop",
        "capability": "专家、属地管理单位和项目负责人共同确认",
        "output": "待人工审核状态",
    },
]


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().upper()


def stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest_json(value: Any) -> str:
    return sha256_text(stable_json(value))


def tokenize_query(query: str) -> List[str]:
    normalized = query.strip().lower()
    if not normalized:
        return []
    terms = [term for term in re.split(r"[\s，。；、！？,.;!?：:（）()\[\]【】]+", normalized) if term]
    expanded: List[str] = []
    for term in terms:
        expanded.append(term)
        if len(term) >= 4:
            expanded.extend(term[index : index + 2] for index in range(len(term) - 1))
    return list(dict.fromkeys(expanded))


def rank_knowledge(
    query: str,
    entries: Sequence[Dict[str, Any]],
    limit: int = 4,
) -> List[Dict[str, Any]]:
    normalized = query.strip().lower()
    terms = tokenize_query(query)
    ranked: List[Dict[str, Any]] = []
    for entry in entries:
        title = str(entry.get("title", "")).lower()
        text = str(entry.get("text", "")).lower()
        citation = str(entry.get("id", entry.get("citation", ""))).upper()
        score = 30 if normalized and normalized in "{} {}".format(title, text) else 0
        matched_terms: List[str] = []
        for term in terms:
            if term in title:
                score += 8
                matched_terms.append(term)
            elif term in text:
                score += 3
                matched_terms.append(term)
        item = dict(entry)
        item["citation"] = "[{}]".format(citation)
        item["score"] = score
        item["matched_terms"] = list(dict.fromkeys(matched_terms))[:8]
        ranked.append(item)
    ranked.sort(key=lambda item: (-int(item["score"]), str(item["citation"])))
    selected = [item for item in ranked if int(item["score"]) > 0][:limit]
    if selected:
        return selected
    return [dict(item, citation="[{}]".format(item.get("id", "")), score=0, matched_terms=[]) for item in entries[:limit]]


def inspect_input(goal: str, query: str) -> Dict[str, Any]:
    text = "{} {}".format(goal, query).strip()
    matches = sorted(set(match.group(0) for match in PROMPT_INJECTION_PATTERN.finditer(text)))
    length_ok = len(goal) <= 500 and len(query) <= 300
    return {
        "passed": length_ok and not matches,
        "length_ok": length_ok,
        "prompt_injection_detected": bool(matches),
        "matches": matches,
        "goal_length": len(goal),
        "query_length": len(query),
        "policy": "不执行绕过、泄露或越权指令，只处理红色遗址保护业务问题。",
    }


def build_generation_prompt(
    site: Dict[str, Any],
    goal: str,
    entries: Sequence[Dict[str, Any]],
) -> str:
    references = "\n".join(
        "- {citation} {title}：{text}".format(
            citation=entry["citation"],
            title=entry["title"],
            text=entry["text"],
        )
        for entry in entries
    )
    return (
        "你是红色遗址数字化保护平台的受控讲解智能体。\n"
        "只依据下列已审核知识条目和任务信息生成250至450字中文初稿。\n"
        "不得补写未提供的人物、时间、地点、事件；不得把概念模型描述为实测成果。\n"
        "必须保留引用编号，至少引用两个知识条目；文末必须写“待审核事项：”并列出至少两项。\n\n"
        "任务目标：{goal}\n"
        "遗址：{site_name}\n"
        "类型：{site_type}\n"
        "记录重点：{focus}\n"
        "模型说明：{model_mode}；{disclaimer}\n\n"
        "已审核知识条目：\n{references}\n"
    ).format(
        goal=goal,
        site_name=site["name"],
        site_type=site["type"],
        focus=site["focus"],
        model_mode=site["model_mode"],
        disclaimer=site["data_disclaimer"],
        references=references,
    )


def build_template_draft(
    site: Dict[str, Any],
    entries: Sequence[Dict[str, Any]],
    fallback_reason: str = "",
) -> str:
    citations = "、".join(entry["citation"] for entry in entries[:3])
    reason = ("\n\n离线降级原因：{}".format(fallback_reason)) if fallback_reason else ""
    return (
        "【待审核初稿】{site_name}数字化保护记录\n\n"
        "{site_name}属于{site_type}。本记录围绕{focus}组织采集、质检、建模和发布任务，"
        "并保留影像、参数、模型指标与审核日志。当前三维资产为{model_mode}，"
        "{disclaimer}\n\n"
        "平台采用多智能体闭环：输入守卫负责边界检查，检索智能体绑定知识来源，"
        "规划智能体拆解业务步骤，生成智能体输出受控初稿，审计智能体复核引用与风险，"
        "最后进入人工审核。\n\n"
        "知识引用：{citations}。\n\n"
        "待审核事项：\n"
        "1. 由属地管理单位确认遗址名称、位置、保护范围和现场资料。\n"
        "2. 由史料专家核验人物、时间、地点、事件及图文版权。"
        "{reason}"
    ).format(
        site_name=site["name"],
        site_type=site["type"],
        focus=site["focus"],
        model_mode=site["model_mode"],
        disclaimer=site["data_disclaimer"],
        citations=citations,
        reason=reason,
    )


def attach_platform_evidence(
    model_response: str,
    site: Dict[str, Any],
    entries: Sequence[Dict[str, Any]],
    model_mode: str,
) -> str:
    citations = "、".join(entry["citation"] for entry in entries)
    return (
        "【模型候选稿｜待证据审计】\n{response}\n\n"
        "平台检索证据：{citations}\n"
        "模型边界：{model_mode}；{disclaimer}\n"
        "待审核事项：\n"
        "1. 核验生成内容中的人物、时间、地点、事件和图片来源。\n"
        "2. 由属地管理单位和史料专家确认后方可发布。"
    ).format(
        response=model_response.strip(),
        citations=citations,
        model_mode=site["model_mode"],
        disclaimer=site["data_disclaimer"],
    )


def audit_generated_content(
    content: str,
    entries: Sequence[Dict[str, Any]],
    model_mode: str,
) -> Dict[str, Any]:
    expected_citations = {str(entry.get("id", "")).upper() for entry in entries}
    found_citations = set(CITATION_PATTERN.findall(content.upper()))
    valid_citations = sorted(found_citations.intersection(expected_citations))
    invalid_citations = sorted(found_citations.difference(expected_citations))
    nonempty_lines = [line.strip() for line in content.splitlines() if len(line.strip()) >= 12]
    line_counts = {line: nonempty_lines.count(line) for line in set(nonempty_lines)}
    max_repetition = max(line_counts.values()) if line_counts else 0
    repeated_lines = sum(count - 1 for count in line_counts.values() if count > 1)
    repetition_ratio = repeated_lines / len(nonempty_lines) if nonempty_lines else 0.0
    repetition_passed = max_repetition <= 2 and repetition_ratio < 0.35
    checks = [
        {
            "id": "repetition_control",
            "label": "重复生成控制",
            "passed": repetition_passed,
            "detail": "重复句占比 {:.1f}%，最高重复 {} 次".format(repetition_ratio * 100, max_repetition)
            if repetition_passed
            else "检测到明显重复段，已触发纠错重写。",
        },
        {
            "id": "unsupported_history_control",
            "label": "无依据历史表述",
            "passed": not any(
                term in content and term not in " ".join(
                    "{} {}".format(entry.get("title", ""), entry.get("text", "")) for entry in entries
                )
                for term in HISTORICAL_CLAIM_TERMS
            ),
            "detail": "未发现知识条目之外的战争或人物史实"
            if not any(
                term in content and term not in " ".join(
                    "{} {}".format(entry.get("title", ""), entry.get("text", "")) for entry in entries
                )
                for term in HISTORICAL_CLAIM_TERMS
            )
            else "检测到知识条目未提供的战争、人物或历史事件表述",
        },
        {
            "id": "citation_coverage",
            "label": "引用覆盖",
            "passed": len(valid_citations) >= 2,
            "detail": "识别到有效引用：{}".format("、".join(valid_citations) or "无"),
        },
        {
            "id": "citation_integrity",
            "label": "引用完整性",
            "passed": not invalid_citations,
            "detail": "无悬空引用" if not invalid_citations else "存在无效引用：{}".format("、".join(invalid_citations)),
        },
        {
            "id": "review_marker",
            "label": "待审核标记",
            "passed": "待审核" in content or "待核验" in content,
            "detail": "已要求进入人工审核" if ("待审核" in content or "待核验" in content) else "缺少待审核标记",
        },
        {
            "id": "concept_disclaimer",
            "label": "模型边界披露",
            "passed": ("概念演示" in content) or ("不可用于" in content) or ("非实测" in content),
            "detail": "已披露概念模型和量测边界"
            if ("概念演示" in content or "不可用于" in content or "非实测" in content)
            else "未发现模型边界披露",
        },
        {
            "id": "length_control",
            "label": "内容长度",
            "passed": 80 <= len(content.strip()) <= 1500,
            "detail": "当前{}字".format(len(content.strip())),
        },
        {
            "id": "external_link_control",
            "label": "外部链接控制",
            "passed": not re.search(r"https?://", content, re.IGNORECASE),
            "detail": "未输出未经授权外链" if not re.search(r"https?://", content, re.IGNORECASE) else "输出包含外部链接",
        },
        {
            "id": "prompt_injection_control",
            "label": "提示注入复核",
            "passed": not PROMPT_INJECTION_PATTERN.search(content),
            "detail": "未发现绕过或泄密模式"
            if not PROMPT_INJECTION_PATTERN.search(content)
            else "输出疑似响应了越权指令",
        },
    ]
    risk_flags: List[Dict[str, str]] = []
    if DATE_PATTERN.search(content):
        risk_flags.append(
            {
                "type": "historical_date",
                "detail": "生成内容包含具体年份或日期，发布前必须逐项核验来源。",
            }
        )
    if PERSON_ROLE_PATTERN.search(content):
        risk_flags.append(
            {
                "type": "historical_person",
                "detail": "生成内容包含人物或职务线索，发布前必须由史料专家确认。",
            }
        )
    if model_mode != "online_model":
        risk_flags.append(
            {
                "type": "template_fallback",
                "detail": "本次不是在线大模型生成，不能作为真实模型输出证据。",
            }
        )
    passed = sum(1 for check in checks if check["passed"])
    score = round(passed * 100 / len(checks))
    return {
        "status": "pass" if passed == len(checks) else "needs_revision",
        "score": score,
        "checks": checks,
        "risk_flags": risk_flags,
        "valid_citations": valid_citations,
        "requires_human_review": True,
        "review_policy": "即使审计通过也必须由人工确认，AI不能替代史料和属地审核。",
    }


def build_stage(
    agent: Dict[str, str],
    status: str,
    artifact: Any,
    started_at: str,
    latency_ms: float,
    evidence: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    payload = {
        "agent_id": agent["id"],
        "name": agent["name"],
        "role": agent["role"],
        "capability": agent["capability"],
        "status": status,
        "artifact": artifact,
        "started_at": started_at,
        "latency_ms": latency_ms,
        "evidence": evidence or {},
    }
    payload["artifact_sha256"] = digest_json(payload["artifact"])
    return payload


def manifest() -> Dict[str, Any]:
    return {
        "name": "HeritageMultiAgentWorkflow",
        "version": PIPELINE_VERSION,
        "agents": AGENT_BLUEPRINT,
        "safety": {
            "human_in_the_loop": True,
            "prompt_injection_guard": True,
            "citation_binding": True,
            "online_offline_disclosure": True,
            "evidence_hash_chain": True,
        },
    }
